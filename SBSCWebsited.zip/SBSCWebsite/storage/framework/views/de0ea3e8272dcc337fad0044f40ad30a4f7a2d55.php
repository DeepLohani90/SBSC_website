<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- BODY START=========== -->
	<div class="vc_row wpb_row vc_row-fluid heroSlider vc_custom_1629910778821"><div class="heroSlider wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629910639097"><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html vc_custom_1629910395611">
		<div class="wpb_wrapper">
			
			<!-- START Slider 2 REVOLUTION SLIDER 6.3.9 --><p class="rs-p-wp-fix"></p>
			<rs-module-wrap id="rev_slider_8_1_wrapper" data-source="gallery" style="background:transparent;padding:0;margin:0px auto;margin-top:0;margin-bottom:0;">
				<rs-module id="rev_slider_8_1" style data-version="6.3.9">
					<rs-slides>
						<rs-slide data-key="rs-19" data-title="Slide" data-anim="ei:d;eo:d;s:1000;r:0;t:fade;sl:0;">
							<img src="images/transparent.png" alt="Slide" title="Home 1" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer id="slider-8-slide-19-layer-0" data-type="image" data-rsp_ch="on" data-xy="x:c;xo:1px;y:c;" data-text="w:normal;" data-dim="w:1920px;h:805px;" data-frame_999="o:0;st:w;sR:8700;" style="z-index:8;"><img src="images/WeCare-1.jpg" width="1920" height="805" data-no-retina> 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-12" data-type="text" data-color="#f26722" data-rsp_ch="on" data-xy="x:624px;y:319px;" data-text="w:normal;s:44;l:31;fw:700;" data-frame_0="x:-50;" data-frame_1="st:1580;sp:1000;sR:1580;" data-frame_999="o:0;st:w;sR:6420;" style="z-index:14;font-family:Montserrat;">SUPERPOWER 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-13" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:33px;y:236px;" data-text="w:normal;s:44;l:31;fw:700;" data-frame_0="x:50;" data-frame_1="st:310;sp:1000;sR:310;" data-frame_999="o:0;st:w;sR:7690;" style="z-index:9;font-family:Montserrat;">WE 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-14" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:31px;y:273px;" data-text="w:normal;s:111;l:79;fw:700;" data-frame_0="o:1;" data-frame_0_chars="d:5;x:-105%;o:0;rZ:-90deg;" data-frame_0_mask="u:t;" data-frame_1="st:830;sp:1200;" data-frame_1_chars="e:power4.inOut;dir:backward;d:10;rZ:0deg;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7430;" style="z-index:11;font-family:Montserrat;">CARING 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-23" data-type="text" data-color="#f26722" data-rsp_ch="on" data-xy="x:128px;y:236px;" data-text="w:normal;s:44;l:31;fw:700;" data-frame_0="x:-50;" data-frame_1="st:300;sp:1000;sR:300;" data-frame_999="o:0;st:w;sR:7700;" style="z-index:10;font-family:Montserrat;">CARE 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-24" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:503px;y:275px;" data-text="w:normal;s:44;l:31;fw:700;" data-frame_0="sX:0.9;sY:0.9;" data-frame_1="st:1360;sp:220;sR:1360;" data-frame_999="o:0;st:w;sR:7420;" style="z-index:12;font-family:Montserrat;"> IS OUR 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-25" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:504px;y:319px;" data-text="w:normal;s:44;l:31;fw:700;" data-frame_0="x:50;" data-frame_1="st:1570;sp:1000;sR:1570;" data-frame_999="o:0;st:w;sR:6430;" style="z-index:13;font-family:Montserrat;">OUR 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-19-layer-26" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:39px;y:382px;" data-text="w:normal;s:16;" data-dim="w:922px;h:80px;" data-frame_1="st:2580;sR:2580;" data-frame_999="o:0;st:w;sR:6120;" style="z-index:15;font-family:Montserrat;">Customers Are the Lifeblood of Our Business. We Work Towards Building Trust Right From the First Conversation and Have a Lasting Impact Through Our Actions. 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide data-key="rs-15" data-title="Slide" data-anim="ei:d;eo:d;s:1070;r:0;t:fade;sl:0;">
							<img src="images/transparent.png" alt="Slide" title="Home 1" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer id="slider-8-slide-15-layer-1" data-type="image" data-rsp_ch="on" data-xy="x:c;" data-text="w:normal;" data-dim="w:1920px;h:805px;" data-frame_1="sp:740;" data-frame_999="o:0;st:w;sR:8260;" style="z-index:8;"><img src="images/hero1.jpg" width="1920" height="805" data-no-retina> 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-2" data-type="text" data-color="rgba(242, 103, 34, 0.86)" data-rsp_ch="on" data-xy="x:951px;y:291px;" data-text="w:normal;s:182;l:228;fw:800;" data-frame_1="st:720;sR:720;" data-frame_999="o:0;st:w;sR:7980;" style="z-index:11;font-family:Montserrat;">O<br>
 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-3" data-type="text" data-color="rgba(242, 103, 34, 0.86)" data-rsp_ch="on" data-xy="x:729px;y:289px;" data-text="w:normal;s:182;l:228;fw:800;" data-frame_1="st:450;sR:450;" data-frame_999="o:0;st:w;sR:8250;" style="z-index:9;font-family:Montserrat;">W 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-4" data-type="text" data-color="rgba(50, 51, 103, 0.86)" data-rsp_ch="on" data-xy="x:1051px;y:289px;" data-text="w:normal;s:182;l:228;fw:800;" data-frame_1="st:880;sR:880;" data-frame_999="o:0;st:w;sR:7820;" style="z-index:12;font-family:Montserrat;">? 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-5" data-type="text" data-color="rgba(50, 51, 103, 0.86)" data-rsp_ch="on" data-xy="x:871px;y:289px;" data-text="w:normal;s:182;l:228;fw:800;" data-frame_1="st:570;sR:570;" data-frame_999="o:0;st:w;sR:8130;" style="z-index:10;font-family:Montserrat;">H 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-6" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:996px;y:395px;" data-text="w:normal;s:17;l:21;" data-frame_1="st:1010;sR:1010;" data-frame_999="o:0;st:w;sR:7690;" style="z-index:13;font-family:Roboto;">WE ARE 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-7" data-type="shape" data-rsp_ch="on" data-xy="x:772px;y:480px;" data-text="w:normal;" data-dim="w:374px;h:2px;" data-frame_1="st:1170;sR:1170;" data-frame_999="o:0;st:w;sR:7530;" style="z-index:14;background-color:rgba(242,103,34,0.5);"> 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-15-layer-8" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:771px;y:498px;" data-text="w:normal;s:14;l:21;fw:300;a:center;" data-dim="w:380;" data-frame_1="st:1340;sR:1340;" data-frame_999="o:0;st:w;sR:7360;" style="z-index:15;font-family:Montserrat;">SBSC is a management and technology consulting company that provides Product Development and Enterprise Technology services to organizations throughout the world.  
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide data-key="rs-17" data-title="Slide" data-anim="ei:d;eo:d;s:1050;r:0;t:fade;sl:0;">
							<img src="images/transparent.png" alt="Slide" title="Home 1" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer id="slider-8-slide-17-layer-9" data-type="image" data-rsp_ch="on" data-xy="x:c;y:c;" data-text="w:normal;" data-dim="w:1920px;h:805px;" data-frame_1="sp:740;" data-frame_999="o:0;st:w;sR:8260;" style="z-index:8;"><img src="images/hero2New2.jpg" width="1920" height="805" data-no-retina> 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-17-layer-10" data-type="text" data-color="#2e3060" data-rsp_ch="on" data-xy="x:270px;y:211px;" data-text="s:46;l:96;fw:600;" data-frame_0="x:-50;" data-frame_1="st:180;sp:1000;sR:180;" data-frame_999="o:0;st:w;sR:7820;" style="z-index:10;font-family:Montserrat;text-transform:uppercase;">Our 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-17-layer-11" data-type="text" data-color="#f26722" data-rsp_ch="on" data-xy="x:268px;y:258px;" data-text="w:normal;s:64;l:94;fw:700;" data-frame_0="x:50;" data-frame_1="st:170;sp:1000;sR:170;" data-frame_999="o:0;st:w;sR:7830;" style="z-index:9;font-family:Montserrat;text-transform:uppercase;">Certification 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-17-layer-15" data-type="text" data-color="#0c0c0c" data-rsp_ch="on" data-xy="x:272px;y:349px;" data-text="w:normal;s:14;l:20;" data-dim="w:508px;h:57px;" data-frame_1="st:720;sp:430;sR:720;" data-frame_999="o:0;st:w;sR:7850;" style="z-index:13;font-family:Montserrat;">New LayerSBSC’s offshore development center in India is certified for ISO 9000:2014 & ISO 27001:2013 and certified for PCI-DSS compliance.  
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-17-layer-16" data-type="image" data-rsp_ch="on" data-xy="x:274px;y:415px;" data-text="w:normal;" data-dim="w:205px;h:51px;" data-frame_1="st:850;sR:850;" data-frame_999="o:0;st:w;sR:7850;" style="z-index:14;"><img src="images/hero2-Logo.png" width="325" height="81" data-no-retina> 
							</rs-layer><!--
-->						</rs-slide>
						<rs-slide data-key="rs-18" data-title="Slide" data-anim="ei:d;eo:d;s:1090;r:0;t:fade;sl:0;">
							<img src="images/transparent.png" alt="Slide" title="Home 1" class="rev-slidebg" data-no-retina>
<!--
							--><rs-layer id="slider-8-slide-18-layer-18" data-type="image" data-rsp_ch="on" data-xy="x:c;" data-text="w:normal;" data-dim="w:1920px;h:805px;" data-frame_999="o:0;st:w;sR:8700;" style="z-index:5;"><img src="images/hero3.jpg" width="1920" height="805" data-no-retina> 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-18-layer-19" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:589px;y:275px;" data-text="w:normal;s:46;fw:600;" data-frame_0="sX:0.9;sY:0.9;" data-frame_1="st:170;sp:1000;" data-frame_999="o:0;st:w;sR:7830;" style="z-index:6;font-family:Montserrat;">HOW ARE WE 
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-18-layer-20" data-type="text" data-color="#f26722" data-rsp_ch="on" data-xy="x:586px;y:293px;" data-text="w:normal;s:74;l:93;fw:700;" data-frame_0="o:1;" data-frame_0_chars="d:5;y:-100%;o:0;rZ:35deg;" data-frame_0_mask="u:t;" data-frame_1="st:660;sp:1200;" data-frame_1_chars="e:power4.inOut;d:10;rZ:0deg;" data-frame_1_mask="u:t;" data-frame_999="o:0;st:w;sR:7340;" style="z-index:7;font-family:Montserrat;">DIFFERENT ?  
							</rs-layer><!--

							--><rs-layer id="slider-8-slide-18-layer-21" data-type="text" data-color="#ffffff" data-rsp_ch="on" data-xy="x:592px;y:382px;" data-text="w:normal;s:14;l:21;" data-dim="w:476px;h:80px;" data-frame_1="st:1370;sR:1370;" data-frame_999="o:0;st:w;sR:7330;" style="z-index:8;font-family:Roboto; font-size:16px !important;">Our management team is deeply involved in sustaining the relationships we create through the fulfillment of both measurable and  intangible goals. We believe in being a strong business partner and “Delivering Differently”<br>
  
							</rs-layer><!--
-->						</rs-slide>
					</rs-slides>
				</rs-module>
				<script type="text/javascript">
					setREVStartSize({c: 'rev_slider_8_1',rl:[1240,1024,778,480],el:[700],gw:[1240],gh:[700],type:'standard',justify:'',layout:'fullwidth',mh:"0"});
					var	revapi8,
						tpj;
					function revinit_revslider81() {
					jQuery(function() {
						tpj = jQuery;
						revapi8 = tpj("#rev_slider_8_1");
						if(revapi8==undefined || revapi8.revolution == undefined){
							revslider_showDoubleJqueryError("rev_slider_8_1");
						}else{
							revapi8.revolution({
								visibilityLevels:"1240,1024,778,480",
								gridwidth:1240,
								gridheight:700,
								perspective:600,
								perspectiveType:"global",
								editorheight:"700,768,960,720",
								responsiveLevels:"1240,1024,778,480",
								progressBar:{disableProgressBar:true},
								navigation: {
									wheelCallDelay:1000,
									onHoverStop:false,
									touch: {
										touchenabled:true,
										touchOnDesktop:true
									},
									arrows: {
										enable:true,
										style:"custom",
										hide_onmobile:true,
										hide_under:778,
										left: {
											h_offset:30
										},
										right: {
											h_offset:30
										}
									},
									bullets: {
										enable:true,
										tmp:"",
										style:"hermes",
										h_align:"right",
										h_offset:20
									}
								},
								fallbacks: {
									allowHTML5AutoPlayOnAndroid:true
								},
							});
						}
						
					});
					} // End of RevInitScript
				var once_revslider81 = false;
				if (document.readyState === "loading") {document.addEventListener('readystatechange',function() { if((document.readyState === "interactive" || document.readyState === "complete") && !once_revslider81 ) { once_revslider81 = true; revinit_revslider81();}});} else {once_revslider81 = true; revinit_revslider81();}
				</script>
				<script>
					var htmlDivCss = unescape("%23rev_slider_8_1_wrapper%20.custom.tparrows%20%7B%0A%09cursor%3Apointer%3B%0A%09background%3A%23000%3B%0A%09background%3Argba%280%2C0%2C0%2C0.5%29%3B%0A%09width%3A40px%3B%0A%09height%3A40px%3B%0A%09position%3Aabsolute%3B%0A%09display%3Ablock%3B%0A%09z-index%3A1000%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows%3Ahover%20%7B%0A%09background%3A%23000%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows%3Abefore%20%7B%0A%09font-family%3A%20%27revicons%27%3B%0A%09font-size%3A15px%3B%0A%09color%3A%23fff%3B%0A%09display%3Ablock%3B%0A%09line-height%3A%2040px%3B%0A%09text-align%3A%20center%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows.tp-leftarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce824%27%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.custom.tparrows.tp-rightarrow%3Abefore%20%7B%0A%09content%3A%20%27%5Ce825%27%3B%0A%7D%0A%0A%0A%23rev_slider_8_1_wrapper%20.hermes.tp-bullets%20%7B%0A%7D%0A%0A%23rev_slider_8_1_wrapper%20.hermes%20.tp-bullet%20%7B%0A%20%20%20%20overflow%3Ahidden%3B%0A%20%20%20%20border-radius%3A50%25%3B%0A%20%20%20%20width%3A16px%3B%0A%20%20%20%20height%3A16px%3B%0A%20%20%20%20background-color%3A%20rgba%280%2C%200%2C%200%2C%200%29%3B%0A%20%20%20%20box-shadow%3A%20inset%200%200%200%202px%20%23ffffff%3B%0A%20%20%20%20-webkit-transition%3A%20background%200.3s%20ease%3B%0A%20%20%20%20transition%3A%20background%200.3s%20ease%3B%0A%20%20%20%20position%3Aabsolute%3B%0A%7D%0A%0A%23rev_slider_8_1_wrapper%20.hermes%20.tp-bullet%3Ahover%20%7B%0A%09%20%20background-color%3A%20rgba%280%2C0%2C0%2C0.21%29%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.hermes%20.tp-bullet%3Aafter%20%7B%0A%20%20content%3A%20%27%20%27%3B%0A%20%20position%3A%20absolute%3B%0A%20%20bottom%3A%200%3B%0A%20%20height%3A%200%3B%0A%20%20left%3A%200%3B%0A%20%20width%3A%20100%25%3B%0A%20%20background-color%3A%20%23ffffff%3B%0A%20%20box-shadow%3A%200%200%201px%20%23ffffff%3B%0A%20%20-webkit-transition%3A%20height%200.3s%20ease%3B%0A%20%20transition%3A%20height%200.3s%20ease%3B%0A%7D%0A%23rev_slider_8_1_wrapper%20.hermes%20.tp-bullet.selected%3Aafter%20%7B%0A%20%20height%3A100%25%3B%0A%7D%0A%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}
				</script>
				<script>
					var htmlDivCss = unescape("%0A%0A%0A%0A%0A%0A%0A%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}
				</script>
			</rs-module-wrap>
			<!-- END REVOLUTION SLIDER -->

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="homeSpace wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1627409338222">
		<div class="wpb_wrapper">
			<h2 class="homePageStyle"><span class="orange">4 Reasons</span> To Choose Us</h2>
<p style="text-align: center;">We Deliver Differently</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap reasons4"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="d-flex">
    <div class>
        <div class="count4">
            <img src="images/one.png">
        </div>
    </div>
    <div class>
        <div class="whyChooseSteps4">
            <h2>Experience</h2>
            <h3>Real-World Experience First-Hand Knowledge</h3>
            <p>With every engagement, our qualified consultants implement best practices and knowledge acquired from the years they spent working in consulting and corporate environments. In fact, our leadership team and consultants have worked in the financial sector for most, if not all, of their careers.</p>
        </div>
      </div>
</div>  
		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="d-flex">
    <div class>
        <div class="count4">
            <img src="images/two.png">
        </div>
    </div>
    <div class>
        <div class="whyChooseSteps4">
            <h2>Flexibility</h2>
            <h3>Scalability Meets Flexibility</h3>
            <p>One size does not fit all: As a private company with a strong entrepreneurial spirit, we are large enough to handle your complex, enterprise-wide projects, yet agile enough to adjust to your specific requirements. This gives us the flexibility needed to work with clients in creative and accommodating ways.</p>
        </div>
      </div>
</div>  
		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap reasons4"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="d-flex">
    <div class>
        <div class="count4">
            <img src="images/three.png">
        </div>
    </div>
    <div class>
        <div class="whyChooseSteps4">
            <h2>Exceptional Value</h2>
            <h3>Exceptional Services At An Exceptional Value</h3>
            <p>Doing more with less is the name of the game in this economic climate. Our size, experience, and approach enable us to offer clients exceptional value without compromising exceptional service.</p>
        </div>
      </div>
</div>  
		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="d-flex">
    <div class>
        <div class="count4">
            <img src="images/four.png">
        </div>
    </div>
    <div class>
        <div class="whyChooseSteps4">
            <h2>Results</h2>
            <h3>Results Your Business Needs</h3>
            <p>Our track record and results-oriented approach enable us to deliver the results your business needs. We tackle your most pressing technology and business issues by combining our proven project management skills with expertise and a strong work ethic.</p>
        </div>
      </div>
</div>  
		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1627322823615 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1627322823615"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1627322823615{background-position:center center !important;}</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<h2 class="homePageStyleWhite"><span>Services</span> We Provide</h2>
<p style="color:#fff; text-align:center;">Day after day, we work with our clients to grow existing businesses and start new ones. 
We uncover opportunities and solve problems.</p>
		</div>
	</div>
<div class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div><div class="vc_row wpb_row vc_inner container bootstrap margZeroServiceCol"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/ApplicationDevelopment.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Application Development</h2>
            <p>Software Business Solutions Consulting’s (SBSC) Application Development services are designed to assist…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/application-development/" title="Application Development">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/mobileApplicationDevelopment.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Mobile Application Development</h2>
            <p>Software Business Solutions Consulting (SBSC) is committed to forming a common architecture to support…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/mobile-application-development/" title="Mobile Application Development">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/ApplicationSupport.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Application Support</h2>
            <p>SBSC’s Application Support Services manages the operation, maintenance, versioning and upgrading of an…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/application-support/" title="Application Support">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/QualityAssurance.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Quality Assurance (QA) Testing</h2>
            <p>The testing services offered within our Testing Center of Excellence (TCoE) provides a framework to expedite business process validation, eliminate…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/quality-assurance-testing/" title="Quality Assurance Testing">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/ProgrameProjectManagement.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Program & Project Management</h2>
            <p>SBSC’s Program, Project and Service Management encompasses the entire application lifecycle to ensure the highest quality by invigorating an…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/program-project-management/" title="Program & Project Management">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc-hoverbox-wrapper  servicesHeadingHomePage vc-hoverbox-shape--square vc-hoverbox-align--center vc-hoverbox-direction--default vc-hoverbox-width--100" ontouchstart>
  <div class="vc-hoverbox">
    <div class="vc-hoverbox-inner">
      <div class="vc-hoverbox-block vc-hoverbox-front" style="background-image: url(images/BusinessIntel.png);">
        <div class="vc-hoverbox-block-inner vc-hoverbox-front-inner">
            
        </div>
      </div>
      <div class="vc-hoverbox-block vc-hoverbox-back" style="background-color: #ebebeb;">
        <div class="vc-hoverbox-block-inner vc-hoverbox-back-inner">
            <h2 style="text-align:center">Business Intelligence Competency</h2>
            <p>SBSC’s Business Intelligence and Data Warehousing Competency offers proven practice of analyzing structured business data. It supports data driven…</p>

            <div class="vc_btn3-container  buttonServices vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-outline vc_btn3-color-grey" href="https://www.sbsc.com/business-intelligence-competency/" title="Business Intelligence Competency">Read More...</a></div>
        </div>
      </div>
    </div>
  </div>
</div></div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1630665276070 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1630665276070"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1630665276070{background-position:left top !important;}</style><div class="homeSpace wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1627409229718">
		<div class="wpb_wrapper">
			<h2 class="homePageStyle">Our <span class="orange">Frameworks</span></h2>
<p style="text-align: center;">General Tools and Applications</p>

		</div>
	</div>
</div></div></div></div><section class="services"><div class="container"><div class="row"><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-boxes" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-boxes" aria-hidden="true"></i></div><h3>Inventory Management System</h3><p></p><div>
<p><a href="https://www.sbsc.com/inventory-management-system/" class="ctkm">Click to know more</a></p>
</div></div></div><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-laptop-medical" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-laptop-medical" aria-hidden="true"></i></div><h3>Computerized Maintenance Management Systems</h3><p></p><div>
<p><a href="https://www.sbsc.com/computerized-maintenance-management-system/" class="ctkm">Click to know more</a></p>
</div></div></div><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-network-wired" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-network-wired" aria-hidden="true"></i></div><h3>Workflow Management Systems</h3><p></p><div>
<p><a href="https://www.sbsc.com/workflow-management-system/" class="ctkm">Click to know more</a></p>
</div></div></div></div></div></section><section class="services"><div class="container"><div class="row"><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-ambulance" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-ambulance" aria-hidden="true"></i></div><h3>Emergency Department Information System</h3><p></p><div>
<p><a href="https://www.sbsc.com/emergency-department-information-system/" class="ctkm">Click to know more</a></p>
</div></div></div><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-first-aid" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-first-aid" aria-hidden="true"></i></div><h3>Healthcare Vendor Management System</h3><p></p><div>
<p><a href="https://www.sbsc.com/healthcare-vendor-management-system/" class="ctkm">Click to know more</a></p>
</div></div></div><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-luggage-cart" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-luggage-cart" aria-hidden="true"></i></div><h3>Online Market<br>Place</h3><p></p><div>
<p><a href="https://www.sbsc.com/online-market-place/" class="ctkm">Click to know more</a></p>
</div></div></div></div></div></section><section class="services"><div class="container"><div class="row"><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-business-time" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-business-time" aria-hidden="true"></i></div><h3>Portfolio Management Office Tool</h3><p></p><div>
<p><a href="https://www.sbsc.com/portfolio-management-office-too/" class="ctkm">Click to know more</a></p>
</div></div></div><div class="col-sm-4"><div class="content text-center"><div class="slide-icon"><i class="fonticon fonticon1 fas fa-scroll" aria-hidden="true"></i><i class="fonticon fonticon2 fas fa-scroll" aria-hidden="true"></i></div><h3>Electronic Transcript Management System</h3><p></p><div>
<p><a href="https://www.sbsc.com/electronic-transcript-management-system/" class="ctkm">Click to know more</a></p>
</div></div></div></div></div></section></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1627031206823 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1627031206823"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1627031206823{background-position:center center !important;}</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html vc_custom_1630501026808">
		<div class="wpb_wrapper">
			<h2 class="homePageStyleWhite">Client <span>Success</span> Stories</h2>
		</div>
	</div>
<div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  whiteText">
		<div class="wpb_wrapper">
			<p style="text-align: center;">We’re proud of our clients and the solutions that we’ve developed to help them achieve success across their various industries. We wish we could go into greater detail about the work we did, however, much of the work we do is confidential but we can provide you with an overview of some of the clients we’ve served.</p>

		</div>
	</div>
</div></div></div></div><div class="vc_tta-container vc_tta-o-non-responsive" data-vc-action="collapse"><div class="vc_general vc_tta vc_tta-tabs vc_tta-o-shape-group vc_tta-has-pagination  testimonialsHome vc_tta-o-no-fill vc_tta-tabs-position-top  vc_tta-pageable vc_custom_1633078776845"><div class="vc_tta-panels-container"><ul class="vc_general vc_pagination vc_pagination-style-flat vc_pagination-shape-round vc_pagination-color-white"><li class="vc_pagination-item vc_active" data-vc-tab><a href="#1627034065638-66c2d9bc-bb9a" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1627034065649-0f6cfb9b-84f8" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1627045160029-7b8c1741-ed09" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630495894395-068320a3-02b1" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630496407186-2eed19b1-8940" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630496696275-05f05f81-5527" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630497602680-f1d6495c-1cb3" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630497708382-00d3034e-ab35" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630497890617-8c535338-3443" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1630498301475-8fd8ccc2-a996" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li></ul><div class="vc_tta-panels"><div class="vc_tta-panel vc_active" id="1627034065638-66c2d9bc-bb9a" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1627034065638-66c2d9bc-bb9a"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p><img decoding="async" loading="lazy" width="142" height="167" class="alignnone size-full wp-image-628 aligncenter" style="width: 104px;" src="images/etisalat-testimonials.png" alt></p>
<p style="text-align: center;">One of the biggest Telecom service provider in Nigeria, Etisalat, is utilizing SBSC’s Learning management framework for a subscription and usage based knowledge and learning requirements of its customers.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1627034065649-0f6cfb9b-84f8" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1627034065649-0f6cfb9b-84f8"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1221" src="images/medchive.png" alt width="270" height="55"></p>
<p style="text-align: center;">As the healthcare industry continues to evolve, we’ve worked with Medchive to develop a groundbreaking online solution to serve hospitals, physicians, and patients.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1627045160029-7b8c1741-ed09" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1627045160029-7b8c1741-ed09"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="size-full wp-image-1223 aligncenter" src="images/medefies.png" alt width="270" height="55"></p>
<p style="text-align: center;">A leading provider of healthcare vendor management systems, Medefis sought our help to revamp their back-end systems, as well as their front-end site.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630495894395-068320a3-02b1" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630495894395-068320a3-02b1"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1225" src="images/LASUTH.png" alt width="142" height="164"></p>
<p style="text-align: center;">The Lagos State University Teaching Hospital Ikeja emerged from a modest cottage hospital to the Lagos State Univesity Teaching Hospital in a short time. We have implemented SBSC Healthcare and emergency department management system at Lasuth.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630496407186-2eed19b1-8940" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630496407186-2eed19b1-8940"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1227" src="images/LRHU.png" alt width="139" height="179"></p>
<p style="text-align: center;">Lagos’s renowned hospital utilized our web designing and development services to facilitate its website.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630496696275-05f05f81-5527" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630496696275-05f05f81-5527"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1229" src="images/ViewPoint.png" alt width="142" height="59"></p>
<p style="text-align: center;">Abuja’s Viewpoint hospital is a known name in Medical services and is leveraging SBSC’s medical services and emergency department management system to serve its clients effectively.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630497602680-f1d6495c-1cb3" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630497602680-f1d6495c-1cb3"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1231" src="images/glo.png" alt width="148" height="147"></p>
<p style="text-align: center;">Globacom, A telecom services giant fron Nigeria, is using SBSC’s inventory and procurement framework for maintaining its network and radio equipment and assets.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630497708382-00d3034e-ab35" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630497708382-00d3034e-ab35"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1232" src="images/Jaiz.png" alt width="145" height="92"></p>
<p style="text-align: center;">Jaiz Bank, a Islamic Bank from Abuja has hired us for building a complete internet banking web suite for its retail and corporate customers.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630497890617-8c535338-3443" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630497890617-8c535338-3443"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1234" src="images/metroBus.png" alt width="146" height="37"></p>
<p style="text-align: center;">Lagos’s Leading public transportation provider uses our designed Ticket verification and reconciliation solution.</p>

		</div>
	</div>
</div></div><div class="vc_tta-panel" id="1630498301475-8fd8ccc2-a996" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1630498301475-8fd8ccc2-a996"></a>
			</span>
		
	<div class="wpb_text_column wpb_content_element  testimonialsTxt">
		<div class="wpb_wrapper">
			<p style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone size-full wp-image-1238" src="images/GNPC.png" alt width="113" height="186"></p>
<p style="text-align: center;">We have provided a work flow management system to cater to work flows, approvals and authorization system for Ghana National Petroleum Commission.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1630665276070 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1630665276070"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1630665276070{background-position:left top !important;}</style><div class="homeSpace wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1634463895709">
		<div class="wpb_wrapper">
			<h2 class="homePageStyle"><span class="orange">Consultation</span> Services</h2>
<p style="text-align: center;">We can help you develop and execute a clear and strategic IT roadmap with priorities that are closely linked to business goals.</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1634464870273"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left  vc_custom_1634462264930">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="417" height="417" src="images/cs1.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy" srcset="images/cs1.jpg 417w, images/cs1-300x300.jpg 300w, images/cs1-150x150.jpg 150w" sizes="(max-width: 417px) 100vw, 417px"></div>
		</figure>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1634463999217 cs-class">
		<div class="wpb_wrapper">
			<h2 style="text-align: center;">IT Strategy & Planning</h2>
<p style="text-align: center;">With our roadmap of initiatives that are tied directly to business outcomes and complete with a detailed plan and a rock-solid timeline and budget, we can bring your organization up to speed; we can guide you with the best possible answers to the most complex technical challenges, and provide end-to-end tech assistance that best fits your unique organization.</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left  vc_custom_1634462302454">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="417" height="417" src="images/cs3.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy" srcset="images/cs3.jpg 417w, images/cs3-300x300.jpg 300w, images/cs3-150x150.jpg 150w" sizes="(max-width: 417px) 100vw, 417px"></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  cs-class">
		<div class="wpb_wrapper">
			<h2 style="text-align: center;">IT Service Management Assessment</h2>
<p style="text-align: center;">We follow a structured engagement approach to assess, analyze, and develop value-added recommendations to augment your ITSM processes. We make sure to carry out a “future-needs” assessment and provide necessary direction with respect to your IT infrastructure, IT organization, and operational processes and procedures.</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left  vc_custom_1634462315299">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="417" height="417" src="images/cs2.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy" srcset="images/cs2.jpg 417w, images/cs2-300x300.jpg 300w, images/cs2-150x150.jpg 150w" sizes="(max-width: 417px) 100vw, 417px"></div>
		</figure>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  cs-class">
		<div class="wpb_wrapper">
			<h2 style="text-align: center;">Business Processes and Cost Optimization</h2>
<p style="text-align: center;">Our information technology consultants leverage their experience and tools to analyze your spending, research your existing licensing contracts, and review your technology usage. We look at your data capture scenarios and search for opportunities to streamline the process, improve workflow, and automate your consumption.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1631796280262 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1631796280262"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1631796280262{background-position:right center !important;}</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<h2 class="homePageStyle" style="text-align:left">Get In<span> Touch</span></h2>
<p text-align:left;">Leave your message and we'll get back to you shortly</p>
		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_hidden-md vc_hidden-sm vc_hidden-xs"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="wpforms-container wpforms-container-full formContactHome" id="wpforms-740"><form id="wpforms-form-740" class="wpforms-validate wpforms-form wpforms-ajax-form" data-formid="740" method="post" enctype="multipart/form-data" action="/" data-token="8b3de894ac3847896e8c03e43b9239c8"><noscript class="wpforms-error-noscript">Please enable JavaScript in your browser to complete this form.</noscript><div class="wpforms-field-container"><div id="wpforms-740-field_1-container" class="wpforms-field wpforms-field-text homeContactField" data-field-id="1"><label class="wpforms-field-label" for="wpforms-740-field_1">Name <span class="wpforms-required-label">*</span></label><input type="text" id="wpforms-740-field_1" class="wpforms-field-large wpforms-field-required" name="wpforms[fields][1]" required></div><div id="wpforms-740-field_4-container" class="wpforms-field wpforms-field-email homeContactField" data-field-id="4"><label class="wpforms-field-label" for="wpforms-740-field_4">Email <span class="wpforms-required-label">*</span></label><input type="email" id="wpforms-740-field_4" class="wpforms-field-large wpforms-field-required" name="wpforms[fields][4]" required></div><div id="wpforms-740-field_5-container" class="wpforms-field wpforms-field-number homeContactField" data-field-id="5"><label class="wpforms-field-label" for="wpforms-740-field_5">Phone</label><input type="number" pattern="\d*" id="wpforms-740-field_5" class="wpforms-field-large" name="wpforms[fields][5]" placeholder="Phone with country code"></div><div id="wpforms-740-field_6-container" class="wpforms-field wpforms-field-textarea homeContactField" data-field-id="6"><label class="wpforms-field-label" for="wpforms-740-field_6">Message <span class="wpforms-required-label">*</span></label><textarea id="wpforms-740-field_6" class="wpforms-field-medium wpforms-field-required" name="wpforms[fields][6]" required></textarea></div></div><div class="wpforms-submit-container"><input type="hidden" name="wpforms[id]" value="740"><input type="hidden" name="wpforms[author]" value="1"><input type="hidden" name="wpforms[post_id]" value="261"><button type="submit" name="wpforms[submit]" class="wpforms-submit btnContact" id="wpforms-submit-740" value="wpforms-submit" aria-live="assertive" data-alt-text="Sending..." data-submit-text="Submit">Submit</button><img src="fonts/submit-spin.svg" class="wpforms-submit-spinner" style="display: none;" width="26" height="26" alt></div></form></div>  <!-- .wpforms-container --></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6 vc_hidden-md vc_hidden-sm vc_hidden-xs"><div class="vc_column-inner "><div class="wpb_wrapper"></div></div></div></div></div></div></div></div>
</div>
<!-- End of main-content -->
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\SBSC\new_site\resources\views/SBSC/index.blade.php ENDPATH**/ ?>