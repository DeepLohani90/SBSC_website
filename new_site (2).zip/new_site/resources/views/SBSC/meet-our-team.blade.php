@include('../SBSC/header')

<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1631170662601{margin-bottom: 50px !important;}.vc_custom_1631170906981{padding-top: 25px !important;padding-right: 25px !important;padding-bottom: 25px !important;padding-left: 25px !important;background-color: #f0f0f0 !important;}.vc_custom_1631170972594{padding-top: 25px !important;padding-right: 25px !important;padding-bottom: 25px !important;padding-left: 25px !important;background-color: #f0f0f0 !important;}.vc_custom_1630567493247{padding-top: 25px !important;padding-right: 25px !important;padding-bottom: 25px !important;padding-left: 25px !important;background-color: #f0f0f0 !important;}.vc_custom_1630567722273{padding-top: 25px !important;padding-right: 25px !important;padding-bottom: 25px !important;padding-left: 25px !important;background-color: #f0f0f0 !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="https://www.sbsc.com/wp-content/uploads/2021/09/sbscFav.png">

	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1631170662601">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Company Overview</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Meet</span> Some Of Our Team</h1>

		</div>
	</div>
</div></div></div></div><div class="vc_tta-container vc_tta-o-non-responsive" data-vc-action="collapse"><div class="vc_general vc_tta vc_tta-tabs vc_tta-o-shape-group vc_tta-has-pagination vc_tta-o-no-fill vc_tta-tabs-position-top  vc_tta-pageable"><div class="vc_tta-panels-container"><ul class="vc_general vc_pagination vc_pagination-style-outline vc_pagination-shape-round vc_pagination-color-orange"><li class="vc_pagination-item vc_active" data-vc-tab><a href="#1631170801085-a1551a22-1e7b" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li><li class="vc_pagination-item" data-vc-tab><a href="#1631170929990-c85d3502-d835" class="vc_pagination-trigger" data-vc-tabs data-vc-container=".vc_tta"></a></li></ul><div class="vc_tta-panels"><div class="vc_tta-panel vc_active" id="1631170801085-a1551a22-1e7b" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1631170801085-a1551a22-1e7b"></a>
			</span>
		<div class="vc_row wpb_row vc_inner container bootstrap meetOurTeam"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1631170906981 imgTeam">
		<div class="wpb_wrapper">
			<div style="text-align: center;"><img decoding="async" class="alignnone wp-image-1032" src="images/AbdulBalogun.jpg" alt width="220" height="220" srcset="images/AbdulBalogun.jpg 220w, images/AbdulBalogun-150x150.jpg 150w" sizes="(max-width: 220px) 100vw, 220px"></div>
<p class="p1" style="text-align: center;"><b>Abdul Balogun<br>
</b></p>
<div class="role" style="text-align: center;">Managing Partner<br>
SBSC Global</div>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-9"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p><strong>Abdul Balogun<br>
</strong>Managing Partner, SBSC Global</p>
<p>As Managing Partner of the SBSC organization, Abdul works with clients in Asia, Europe, the Middle East, Africa and the Americas to help resolve complex business challenges and gain a competitive advantage by developing winning strategies, process re-engineering and optimization, and the use of innovative technology solutions. Abdul’s consulting and leadership philosophy is based on the principle of ‘practical vs. perfect’ answers. Abdul seeks consulting approaches and solutions that are practical, relevant, workable and implementable.</p>
<p>Abdul has extensive experience in large-scale business and technology transformations and has worked on all aspects of information technology value management. Over the course of his career he has developed extensive expertise in business solutions and information technology strategies for financial and retail services, healthcare, oil and gas, telecom, media and manufacturing clients. He has led a number of pre and post-acquisitions integrations in financial and health services with focus on technology and operations, as well as due-diligence projects across many industries.</p>
<p>Abdul is the Vice Chairman for the IT Strategy Group of the Dallas Minority Supplier Development Council. By surrounding himself around other progressive minority business leaders, he is able to share success stories and stay on top of best practices and leading edge solutions in the industry.</p>
<p>Before SBSC, Abdul held various leadership roles across various industries, most recently at American Express within the Global Commercial Card and Global Network Services. Abdul holds a Bachelors and Post Graduate Degree in Electrical and Electronics Engineering, specializing in Radio Frequency Design, Fuzzy Logic, Neural Networks and Pattern Recognition.</p>

		</div>
	</div>
</div></div></div></div></div></div><div class="vc_tta-panel" id="1631170929990-c85d3502-d835" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-body">
			<span class="vc_tta-panel-title">
				<a data-vc-container=".vc_tta-container" data-vc-accordion data-vc-target="#1631170929990-c85d3502-d835"></a>
			</span>
		<div class="vc_row wpb_row vc_inner container bootstrap meetOurTeam"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1631170972594 imgTeam">
		<div class="wpb_wrapper">
			<div style="text-align: center;"><img decoding="async" loading="lazy" class="alignnone wp-image-1042 size-full" src="images/CoryRuth.png" alt width="220" height="220" srcset="images/CoryRuth.png 220w, images/CoryRuth-150x150.png 150w" sizes="(max-width: 220px) 100vw, 220px"></div>
<p class="p1" style="text-align: center;"><b>Cory Ruth</b></p>
<div class="role" style="text-align: center;">Managing Partner<br>
East Coast Region</div>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-9"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p><strong>Cory Ruth<br>
</strong>Managing Partner, East Coast Region</p>
<p>Cory Ruth is a 20-year technology professional. He has managed critical multi-million dollar projects around the globe, most recently successfully leading the technology integration for NCR’s 650MM acquisition of Retalix, an Israeli software firm. For his work on the NCR acquisition his team was awarded the CFO Excellence Award for the Global Payroll Integration. Appointed in 2013 by Governor Nathan Deal, Cory is a member of the Georgia Technology Authority Board of Directors and Georgia Science, Technology Commission Executive Committee Member and the chair of the MAP CIO Roundtable. He has built an impressive portfolio of business in Israel starting with his recruitment of key Atlanta-based executives from a number of Fortune 100 firms to participate in a recent economic development mission to Israel focused on cyber security in collaboration with the Georgia Department of Economic Development and Mayor Kasim Reed. He is an Oglethorpe University and Georgetown University Masters of Technology Management alum. Cory lives in Atlanta with his wife Kathleen and three children, Josiah, Kinsley and Knox.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div></div></div></div></div></div></div>
</div>
@include('../SBSC/footer')