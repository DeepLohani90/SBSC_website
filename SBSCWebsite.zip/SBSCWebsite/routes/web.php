<?php
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\MailController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('SBSC/index');
});
Route::view("application-development","SBSC/application-development");
Route::view("mobile-application-development","SBSC/mobile-application-development");
Route::view("application-support","SBSC/application-support");
Route::view("quality-assurance-testing","SBSC/quality-assurance-testing");
Route::view("program-project-management","SBSC/program-project-management");
Route::view("business-intelligence-competency","SBSC/business-intelligence-competency");
Route::view("consultation-services","SBSC/consultation-services");
Route::view("electronic-transcript-management-system","SBSC/electronic-transcript-management-system");
Route::view("emergency-department-information-system","SBSC/emergency-department-information-system");
Route::view("healthcare-vendor-management-system","SBSC/healthcare-vendor-management-system");
Route::view("online-market-place","SBSC/online-market-place");
Route::view("portfolio-management-office-too","SBSC/portfolio-management-office-too");
Route::view("retail","SBSC/retail");
Route::view("education","SBSC/education");
Route::view("healthcare","SBSC/healthcare");
Route::view("oil-and-gas","SBSC/oil-and-gas");
Route::view("board-of-advisors","SBSC/board-of-advisors");
Route::view("our-partnerships","SBSC/our-partnerships");
Route::view("inventory-management-system","SBSC/inventory-management-system");
Route::view("computerized-maintenance-management-system","SBSC/computerized-maintenance-management-system");
Route::view("workflow-management-system","SBSC/workflow-management-system");
Route::view("mission-vision-values","SBSC/mission-vision-values");
Route::view("corporate-social-responsibility","SBSC/corporate-social-responsibility");
Route::view("global-locations","SBSC/global-locations");
Route::view("india","SBSC/india");
Route::view("sbsc-india","SBSC/sbsc-india");
Route::view("sbsc-africa","SBSC/sbsc-africa");
Route::view("usa","SBSC/usa");
Route::view("africa","SBSC/africa");
Route::view("contact-us","SBSC/contact-us");
Route::view("contact-us","SBSC/contact-us");
Route::view("meet-our-team","SBSC/meet-our-team");
Route::view("finance","SBSC/finance");
Route::view("dummy","SBSC/dummy");

Route::post('/', [MailController::class, 'index']);





