@include('../SBSC/header')
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Portfolio Management</span> Office Tool</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>The impact of information technology, new systems as well as improvements in distribution and services has changed the environment in which organizations compete. Large organizations cannot afford to treat their projects as isolated efforts. With dozens or even hundreds of projects underway at any given time, a strategic approach to portfolio management is the only way to avoid duplicated efforts, conflicting agendas and problems with resource allocation. Because of the focus on broader business visibility, portfolio theory is catching pace to cross pollinate the service automation market.</p>
<p>Portfolio Management Office by SBSC is designed to allow your organization to centrally manage processes, methods and technologies, analyze and collectively manage / control current or proposed projects / programs / portfolios based on numerous key characteristics and to optimally utilize resources for delivery of scheduled activities to best achieve an organization’s operational and financial goals.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1" style="margin-bottom: 0px !important;"><b>Project &amp; Portfolio Management</b></p>
<ul style="list-style-type: disc; padding-left: 14px; margin-bottom: 29px;">
<li>Better controls incoming projects.</li>
<li>Align your portfolios with business goals and strategies.</li>
<li>Get a quick and reliable overview of your entire portfolio and projects.</li>
<li>Effectively manage project operations across your company.</li>
</ul>
<p class="p1" style="margin-bottom: 0px !important;"><b>Resource Management</b></p>
<ul style="list-style-type: disc; padding-left: 14px; margin-bottom: 29px;">
<li>Optimize the use of human, capital, and equipment assets.</li>
<li>Deploy resources efficiently and assign them to projects based on need, qualifications, and availability.</li>
<li>Identify and deploy resources according to organizational structure and approval workflows.</li>
<li>Maintain up-to-date information about employees’ skills and experience.</li>
</ul>
<p class="p1"><b>Monitoring &amp; Control<br>
</b>Improve productivity by utilizing shortcuts and accessing charts that provide real time metrics such as receivables, to-do list and requests access to HMOs.</p>
<p class="p1" style="margin-bottom: 0px !important;"><b>Budget &amp; Cost Management</b></p>
<ul style="list-style-type: disc; padding-left: 14px; margin-bottom: 29px;">
<li>Monitor time, budgets, and expenses for both billable and non-billable activities.</li>
<li>Report on estimates versus actual costs for projects and portfolios.</li>
<li>Integrate with existing financial systems, which supply required data such as labour costs for specific roles and individual resources.</li>
</ul>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Better Decision Making<br>
</b>Eases the prediction of future impacting factors and past project metrics enabling decision makers to identify current contributing and non-contributing portfolios in addition to improved understanding project delivery dependencies.</p>
<p class="p1"><b>Minimize Risk<br>
</b>Ability to avoid or reduce exposure to risks under categories such as finance, governance, and resource utilization. Provides an accountability framework to manage and control the right level of compliances to be followed through every project lifecycle.</p>
<p class="p1"><b>Optimize Resources<br>
</b>The greater degree of visibility resulting in a centralized approach that reduces project costs by reduction or elimination of duplicate efforts.</p>
<p class="p1"><b>Value to Stakeholders<br>
</b>Stakeholders will have centralized access to programs and projects as well as the ability to provide valuable strategies, insights, and feedback to ensure that projects receive the required support.</p>
<p class="p1"><b>Enable Repeatable Success<br>
</b>Establish and document best practices and proven project management methodologies and enforce their usage throughout the organization. Additionally, real-time data can be used to continually improve project operations and results.</p>

		</div>
	</div>
</div></div></div></div>
</div>
@include('../SBSC/footer')