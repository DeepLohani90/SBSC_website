@include('../SBSC/header')
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Computerized Maintenance</span> Management System</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>Given the need for a quick response to today’s dynamic market, maintenance function is considered increasingly important for industrial companies. Maintenance operations are vital parts as they have strong impact on organization’s ability to provide quality and timely services to customers. The significance of efficiently maintaining and utilizing aging equipment has gradually gained importance -specifically, maximizing uptime to meet production demands without increasing costs-is crucial for coherent performance of manufacturing processes and overall health of businesses.</p>
<p>To keep up the operations at maximum efficiency, strategic information system becomes essential. SBSC Presents “Computerized Maintenance Management System” to support maintenance strategy based on an information system and a set of functions that process data to produce indicators to support maintenance activities. Our CMMS tool empowers the organizations to carry out preventive maintenance schedules to enhance the use of data and enable mobility.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Dashboard<br>
</b>The dashboard shows the module widgets that are accessible based on user roles, view notifications and status of raised or pending work orders and service request.</p>
<p class="p1"><b>Service Request Module<br>
</b>The dashboard shows the module widgets that are accessible based on user roles, view notifications and status of raised or pending work orders and service request.</p>
<p class="p1"><b>Inventory Module<br>
</b>The inventory module tracks the items purchased and used to maintain assets. The inventory module track cost and vendor item is purchased from.</p>
<p class="p1"><b>Problem Module<br>
</b>Problem module defines the configuration and problem which helps during creation of service request and work order management.</p>
<p class="p1"><b>Work Order Module<br>
</b>Work order module maintains detailed information about all work orders created by requester.</p>
<p class="p1"><b>Report Module<br>
</b>Report module helps managers to make informed decisions on maintenance trends based on service request and work order. The report module can be customized.</p>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Reduce Work Outages<br>
</b>It aids in preventive maintenance i.e. regularly checking &amp; maintaining equipment and meeting safety standards to prevent malfunctions and critical failures. This minimizes the loss of work time due to accidents and surprise breakdowns. This results in longer equipment life thereby reducing repair costs.</p>
<p class="p1"><b>Analyse Data and Trends<br>
</b>It is helpful in analyzing your data and trends, and identifying the problem areas, such as constant damages, low productivity, rising costs etc. With a CMMS system, a manager will be able to keep better track of equipment breakdowns, in addition to the costs involved. A full record of assets and performance helps managers analyze energy usage and plan maintenance spend.</p>
<p class="p1"><b>Enhance Productivity<br>
</b>It eliminates the need of paperwork and manual tracking activities. Its functionality to collect and store information in easily retrievable format, enables the staff to become more productive and boosts their operational efficiency.</p>
<p class="p1"><b>Eases Inventory Control<br>
</b>It allows easy tracking of asset inventory that needs to be maintained enabling better spare parts forecasting to eliminate shortages and minimize existing inventory.</p>

		</div>
	</div>
</div></div></div></div>
</div>
@include('../SBSC/footer')

