@include('../SBSC/header')
<style type="text/css" data-type="vc_custom-css">.container-custom{width:1140px;}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1629449092811{margin-bottom: 100px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629449377724{margin-bottom: 50px !important;}.vc_custom_1629441601791{margin-top: 0px !important;margin-bottom: 0px !important;padding-top: 0px !important;}.vc_custom_1629443258902{margin-bottom: 0px !important;}.vc_custom_1629448714885{margin-bottom: 0px !important;}.vc_custom_1629448601193{margin-bottom: 0px !important;}.vc_custom_1629448763643{margin-bottom: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629449377724">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Careers</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Careers</span> India</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629441601791"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p>At SBSC we provide holistic employment experience with flexibility to balance both your professional and personal life along with the joy of working on latest technologies. Discover the world of innovation, learning, growth and equal opportunities with us. Looking forward for reshaping your career with us.. Listed below are some current openings we are hiring for. Can’t find the vacancy you seek?.. No Worries .. Mail your CV to us at <a href="mailto:careers@sbsc.com">careers@sbsc.com</a> and we will get back to you.</p>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 class="vc_custom_heading vc_custom_1492689453089">Current Job Openings</h4>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="container container-custom"><div class="vc_row wpb_row vc_row-fluid cusContainer vc_custom_1629449092811"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_tta-container" data-vc-action="collapseAll"><div class="vc_general vc_tta vc_tta-accordion vc_tta-color-blue vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-all-clickable"><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel" id="1629437358260-7757595d-33b6" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629437358260-7757595d-33b6" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-headset"></i><span class="vc_tta-title-text">Helpdesk Java/.Net Production Support</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629443258902">
		<div class="wpb_wrapper">
			<p><strong>Experience Range: </strong>2 – 5 years<br>
<strong>Open Positions: </strong>4</p>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>Around 3-5 years of experience in Product Support or Production Support or Operations Support</li>
<li>Jenkins/JIRA/ Clarity/HP tools/AHP/Confluence knowledge preferred</li>
<li>Had coding/ programming experience (preferable Java, else .Net, C, C++ will also do)</li>
<li>Knowledge of troubleshooting builds and other programming languages</li>
<li>Knowledge of build deployment, build configuration and build failure troubleshooting</li>
<li>Basic knowledge of UNIX/LINUX, shell scripting</li>
<li>Knowledge of Jenkins, AnthillPro, Automic  is an added advantage</li>
<li>The candidate should possess good written and verbal communication skills</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div><div class="vc_tta-panel" id="1629448682378-62c948dc-099e" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629448682378-62c948dc-099e" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-server"></i><span class="vc_tta-title-text">Technical Architect</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629448714885">
		<div class="wpb_wrapper">
			<p><strong>Basic Skillset: </strong>Java or .Net<br>
<strong>Experience Range: </strong>10+ Years<br>
<strong>Open Positions: </strong>1</p>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>Must possess strong technical expertise in multiple technologies</li>
<li>String consulting skills to support a varied portfolio of projects</li>
<li>Should be able to provide technical solutions for any new applications and products</li>
<li>Must possess the ability to enhance the existing products</li>
<li>Excellent communication skills</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div><div class="vc_tta-panel" id="1629448576337-bf2f0bd4-52d3" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629448576337-bf2f0bd4-52d3" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-suitcase"></i><span class="vc_tta-title-text">Project Manager</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629448601193">
		<div class="wpb_wrapper">
			<p><strong>Experience Range: </strong>10+ years<br>
<strong>Open Positions: </strong>1</p>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>lead the planning and implementation of project</li>
<li>facilitate the definition of project scope, goals and deliverables</li>
<li>define project tasks and resource requirements</li>
<li>develop full scale project plans</li>
<li>assemble and coordinate project staff</li>
<li>manage project budget</li>
<li>manage project resource allocation</li>
<li>plan and schedule project timelines</li>
<li>track project deliverables using appropriate tools</li>
<li>provide direction and support to project team</li>
<li>quality assurance</li>
<li>constantly monitor and report on progress of the project to all stakeholders</li>
<li>present reports defining project progress, problems and solutions</li>
<li>implement and manage project changes and interventions to achieve project outputs</li>
<li>project evaluations and assessment of results</li>
<li>PMP and ITIL certified</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div><div class="vc_tta-panel" id="1629448731994-49254293-967b" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629448731994-49254293-967b" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-database"></i><span class="vc_tta-title-text">SQL Developer</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629448763643">
		<div class="wpb_wrapper">
			<p><strong>Experience Range: </strong>5 – 8 years<br>
<strong>Open Positions: </strong>1</p>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>Reviewing query performance and optimizing code</li>
<li>Writing queries used for front-end applications (websites, desktop applications, or cloud apps)</li>
<li>Designing and coding database tables to store the application’s data</li>
<li>Data modelling to visualize database structure</li>
<li>Working with application developers to create optimized queries</li>
<li>Creating database triggers for automation, e.g., automatic email notifications</li>
<li>Creating table indexes to improve database performance</li>
<li>Programming views, stored procedures, and functions</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div></div></div></div></div></div></div></div></div></div>
</div>
@include('../SBSC/footer')
