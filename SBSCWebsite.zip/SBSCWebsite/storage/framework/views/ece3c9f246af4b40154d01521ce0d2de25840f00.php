<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_custom-css">.meetOurTeam .wpb_text_column {
    
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629281565432{margin-bottom: 50px !important;}.vc_custom_1629284358827{border-bottom-width: 4px !important;padding-top: 25px !important;padding-right: 25px !important;padding-bottom: 25px !important;padding-left: 25px !important;background-color: #f0f0f0 !important;border-bottom-color: #f26722 !important;border-bottom-style: solid !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629281565432">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Company Overview</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Board</span> Of Advisors</h1>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap meetOurTeam"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629284358827 imgTeam">
		<div class="wpb_wrapper">
			<div style="text-align: left;"><b>David Taiwo</b></div>
<div class="role" style="text-align: left;">
<p>With an extensive background in software development, David lends expertise in software architecture, product management and development, strategy, and implementation. He holds an engineering degree from Carleton University in Canada and a postgraduate degree in applied information technology from Information Technology Institute (ITI) in Canada. David is the President and CEO of Stemdot Business Solutions.</p>
<p>“The creative and innovative solutions developed by your SBSC team, complemented with your best-in-class customer service and dedication, is superb!!! Today, so many companies have less than stellar customer service; it is great to find a company that cares and does the right thing. Your company will have our business for a long time to come.” David Taiwo, Medefis.</p>
</div>

		</div>
	</div>
</div></div></div></div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/board-of-advisors.blade.php ENDPATH**/ ?>