<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_custom-css">.areaPointBG{
    padding: 30px;
    margin: 20px;
    background: #ffffffd1;
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628782155948{margin-left: 0px !important;padding-left: 0px !important;}.vc_custom_1629208409012{padding-bottom: 20px !important;}.vc_custom_1629207778063{padding-top: 20px !important;padding-bottom: 20px !important;}.vc_custom_1630921942710{background-image: url(images/education.jpg) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1629208409012{padding-bottom: 20px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Industries</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Education</span></h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>Technological advancements are a key contributor to the forces that drive the current changes within the education sector across the globe. Educators of all levels (K-12 as well as higher education) are becoming increasingly aware of the need to leverage innovative technology and tools into curriculums and instructing methodologies. Today’s student is tech savvy and outdated approaches to education are ill equipped to deliver an enhanced educational experience</p>
<p>Having access to information, anytime from anywhere, is becoming the defining mantra of digitization in the education sector and the high adoption rate of such digital learning practices is the force behind the entire education ecosystem. Stakeholders who have a wide variety of learning sources require a custom approach to cater to their learning management needs. Access to certification programs by private institutions and training sessions by corporations are increasing in demand. The need for unique assessment methodology support to improve the overall management of result generation and information sharing is also growing.</p>
<p>SBSC has examined this industry closely to determine how we can best serve the unique needs of our clientele. Because of the huge bandwidth of our tailor-made solutions, we have frameworks and services support readily available to help you capitalize on time to market while also providing dependable, high quality products.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 sbscAreasCoveredUL wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1630921942710"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  areaPointBG">
		<div class="wpb_wrapper">
			<ul>
<li class="p1">Education Institutions (including Testing &amp; Assessment Centers)</li>
<li>Certification Associations</li>
<li class="p1">Corporate Training</li>
<li>Distance Learning</li>
</ul>

		</div>
	</div>
</div></div></div><div class="serviceBenefitRight wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629208409012">
		<div class="wpb_wrapper">
			<h3 class="h1Original" style="text-align: center;"><span class="orange">Areas</span> Covered</h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 style="text-align: center;">Our expertise will help you to create an exceptional learning experience for all stakeholders of the education ecosystem. We have assisted our clients with:</h4>

		</div>
	</div>

	<div class="wpb_raw_code wpb_content_element wpb_raw_html countingUL">
		<div class="wpb_wrapper">
			<ol>
    <li>
        <div>
        <strong>Program & Technology Optimization</strong>
        <p>Work with various educational facilities and curriculum developers to design and build flexible, dependable and inventive teaching solutions that respond to rapidly changing learning environments. Assist with developing programs to enhance and increase student engagement as well as establishing strategies that address security risks and privacy regulations associated with a model that accommodates 24×7 access.</p>
        </div>
    </li>
    <li>
        <div>
        <strong>Business Intelligence and Analytics</strong>
        <p>Gaining full insight to the changes within an organization is essential to understanding the growing demands of their ecosystem. To achieve this result, our subject matter experts analyze trends and conditions around academic success by utilizing business intelligence models and identify areas of improvement and opportunity.</p>
        </div>
    </li>
<li>
        <div>
            <strong>Application Maintenance and IT Support Augmentation</strong>
            <p>Most educational institutions and corporate learning providers are not equipped to address the technology advancements in education. SBSC’s education instructional designers work with our clients to implement and manage application maintenance governance such as enhancements, preventative maintenance, and release management to ensure application security, service continuity, and continuous improvement. We also work with internal IT departments to augment their existing customer service and support infrastructure by providing Level 1, 2, & 3 service support for both internal and external customers. Our services add value to our clients by allowing them to continue to provide the necessary coverage and support for their applications without needing to shift focus from their core business areas and functions or over taxing resources.</p>
        </div>
    </li>

</ol>
		</div>
	</div>
</div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/new_site/resources/views/SBSC/education.blade.php ENDPATH**/ ?>