<!DOCTYPE html><html lang="en-US"><head>
    <!-- Meta UTF8 charset -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SBSC – Software Business Solutions Consulting</title>
<meta name="robots" content="max-image-preview:large">
<link rel="dns-prefetch" href="//fonts.googleapis.com">
<link rel="alternate" type="application/rss+xml" title="SBSC » Feed" href="https://www.sbsc.com/feed/">
<link rel="alternate" type="application/rss+xml" title="SBSC » Comments Feed" href="https://www.sbsc.com/comments/feed/">
<link rel="alternate" type="application/rss+xml" title="SBSC » Home 1 Comments Feed" href="https://www.sbsc.com/home-1-2/feed/">
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.sbsc.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script><script src="js/wp-emoji-release.min.js" type="text/javascript" defer></script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel="stylesheet" id="wp-block-library-css" href="<?php echo e(asset('css/style.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="classic-theme-styles-css" href="<?php echo e(asset('css/classic-themes.min.css')); ?>" type="text/css" media="all">
<style id="global-styles-inline-css" type="text/css">
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('index_1.html#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('index_1.html#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('index_1.html#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('index_1.html#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('index_1.html#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('index_1.html#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('index_1.html#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('index_1.html#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel="stylesheet" id="contact-form-7-css" href="<?php echo e(asset('css/styles.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="rs-plugin-settings-css" href="<?php echo e(asset('css/rs6.css')); ?>" type="text/css" media="all">
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
#rev_slider_8_1_wrapper .custom.tparrows {
	cursor:pointer;
	background:#000;
	background:rgba(0,0,0,0.5);
	width:40px;
	height:40px;
	position:absolute;
	display:block;
	z-index:1000;
}
#rev_slider_8_1_wrapper .custom.tparrows:hover {
	background:#000;
}
#rev_slider_8_1_wrapper .custom.tparrows:before {
	font-family: 'revicons';
	font-size:15px;
	color:#fff;
	display:block;
	line-height: 40px;
	text-align: center;
}
#rev_slider_8_1_wrapper .custom.tparrows.tp-leftarrow:before {
	content: '\e824';
}
#rev_slider_8_1_wrapper .custom.tparrows.tp-rightarrow:before {
	content: '\e825';
}


#rev_slider_8_1_wrapper .hermes.tp-bullets {
}

#rev_slider_8_1_wrapper .hermes .tp-bullet {
    overflow:hidden;
    border-radius:50%;
    width:16px;
    height:16px;
    background-color: rgba(0, 0, 0, 0);
    box-shadow: inset 0 0 0 2px #ffffff;
    -webkit-transition: background 0.3s ease;
    transition: background 0.3s ease;
    position:absolute;
}

#rev_slider_8_1_wrapper .hermes .tp-bullet:hover {
	  background-color: rgba(0,0,0,0.21);
}
#rev_slider_8_1_wrapper .hermes .tp-bullet:after {
  content: ' ';
  position: absolute;
  bottom: 0;
  height: 0;
  left: 0;
  width: 100%;
  background-color: #ffffff;
  box-shadow: 0 0 1px #ffffff;
  -webkit-transition: height 0.3s ease;
  transition: height 0.3s ease;
}
#rev_slider_8_1_wrapper .hermes .tp-bullet.selected:after {
  height:100%;
}
</style>
<link rel="stylesheet" id="megamenu-css" href="<?php echo e(asset('css/style.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="dashicons-css" href="<?php echo e(asset('css/dashicons.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="wpforms-full-css" href="<?php echo e(asset('css/wpforms-full.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-spin-loader-css" href="<?php echo e(asset('css/spin-loader.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="font-awesome-css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="icomoon-css" href="<?php echo e(asset('css/icomoon.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="bootstrap-css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="owl-carousel-css" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="owl-carousel-theme-css" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="animate-css" href="<?php echo e(asset('css/animate.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="fancybox-css" href="<?php echo e(asset('css/jquery.fancybox.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-main-style-css" href="<?php echo e(asset('css/light_style.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-media_query-css" href="<?php echo e(asset('css/media_query.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="magnific-popup-css" href="<?php echo e(asset('css/magnific-popup.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-vc-css" href="<?php echo e(asset('css/visual-composer.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-flexslider-css" href="<?php echo e(asset('css/flexslider.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-wordpress-css" href="<?php echo e(asset('css/wordpress.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-theme-css" href="<?php echo e(asset('css/nt-antique-theme.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-update-css" href="<?php echo e(asset('css/update.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-woocommerce-css" href="<?php echo e(asset('css/woocommerce.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-fonts-load-css" href="//fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C500%2C700%2C900&amp;subset=latin%2Clatin-ext&amp;ver=1.0.0" type="text/css" media="all">
<link rel="stylesheet" id="nt-antique-custom-style-css" href="<?php echo e(asset('css/style_1.css')); ?>" type="text/css" media="all">
<style id="nt-antique-custom-style-inline-css" type="text/css">
.error404 .index .searchform input[type="submit"], .search .index .searchform input[type="submit"], #widget-area #searchform input#searchsubmit, .widget-title:after, .pager li > a, .pager li > span {background-color:#f26722;}a, a:hover, a:focus, .breadcrumb-current, #widget-area .widget ul li a:hover, #blog .entry-title a:hover, #blog .entry-meta a:hover, #share-buttons i:hover, #blog a:hover, footer .widget ul li a:hover, footer a:hover{color:#f26722;}.pager li > a, .pager li > span, #blog .pager li a:before { border-color:  #f26722; }.error404 .index .searchform input[type="submit"] {background-color:#f26722;}.search .index .searchform input[type="submit"] {background-color:#f26722;}.widget-title:after{background-color:#f26722;}#blog .pager li a:before, .pager li a {border-color:#f26722;}.brand.text-logo, header .navbar-default .navbar-nav li a:hover, header .navbar-default .navbar-nav li a:focus, .fixed_top.navbar-default .navbar-nav li a:hover, .fixed_top.navbar-default .navbar-nav li a:focus, header .navbar-default .navbar-nav li.active a, .fixed_top .navbar-nav li.active a, .mission h3 strong, .services .content .slide-icon .fonticon1, .services .content:hover h3, .services .content .slide-icon, .counter_up .counter, .team .content:not(.transp) h3, .blog-section h6 span, .footer_top h3, .progress-element p span {color:#f26722!important;}.about_us .img_container,.about_us .inner_container, .hvr-trim:before, .mission .border, .mission .txt_container, #blog .pager li a:before  {border-color:#f26722!important;}.section_header h2:after, .services .content .slide-icon, .portfolio .content .fa, .tooltip-inner, .banner .btn, .progress-bar {background-color:#f26722;}.tooltip-inner {color:#fff;}.tooltip-arrow{border-top-color: #f26722!important;border-bottom-color: #f26722!important;}.tooltip-inner {color:#fff;}.navbar-default.fixed_top .navbar-nav li a{color:#f26722!important;}.navbar-default.fixed_top .navbar-nav li a:hover{color:#0a0a0a!important;}@media (max-width: 768px){}.navbar-default .text-logo{font-size:30px!important;}.navbar-default .text-logo{font-weight:100!important;}.navbar-default .text-logo{letter-spacing:0px!important;}.navbar-default .text-logo{font-style:normal!important;}.navbar-default.fixed_top .brand{display: none!important;}.navbar-default.fixed_top .sticky-logo.brand{display: block!important;}.navbar-default.fixed_top .text-logo{font-size:30px!important;}.navbar-default.fixed_top .text-logo{font-weight:700!important;}.navbar-default.fixed_top .text-logo{letter-spacing:0px!important;}#widget-area .widget{}.blog .index-header {min-height: 22vh !important; max-height: 100%; }.blog .index-header .template-overlay{ display:none!important; }.blog .index-header .template-cover-text .uppercase{font-size: 36px; }.blog .index-header .template-cover-text .cover-text-sublead{font-size: 16px; }.page-id-261.index-header {background-image: url()!important; }.page-id-261.index-header { background-image: none!important; }.single .index-header .template-overlay{ display:none!important; }.single .index-header .uppercase{font-size: 65px; }.single .index-header {height: 21vh !important; }@media (min-width: 768px){
			.single .index-header  {
				padding-top: 0px !important;
				padding-bottom: 0px !important;
			}
		}.archive .index-header .template-overlay{ display:none!important; }.archive .index-header  .uppercase{font-size: 65px; }.archive .index-header .cover-text-sublead{font-size: 16px; }.archive .index-header {height: 21vh !important; }@media (min-width: 768px){
			.archive .index-header  {
				padding-top: 0px !important;
				padding-bottom: 0px !important;
			}
		}.error404 .index-header .template-overlay{ display:none!important; }.error404 .index-header .uppercase{font-size: 0px; }.error404 .index-header .cover-text-sublead{font-size: 16px; }.error404 .index-header {height: 50vh !important; }@media (min-width: 768px){
			.error404 .index-header  {
				padding-top: 0px !important;
				padding-bottom: 0px !important;
			}
		}.search .index-header .template-overlay{ display:none!important; }.search .index-header .uppercase{font-size: 0px; }.search .index-header .cover-text-sublead{font-size: 16px; }.search .index-header {height: 21vh !important; }@media (min-width: 768px){
			.search .index-header  {
				padding-top: 0px !important;
				padding-bottom: 0px !important;
			}
		}.footer_top {border-top-color: #2e3060!important; }.footer_top h3, .footer_top h3.widget-head{ color: #ffffff!important; }.footer_top .textwidget, .footer_top .textwidget p, .footer_top .textwidget li{ color: #ffffff!important; }.footer_top .widget ul li a { color: #ffffff!important; }.footer_top .widget ul li a:hover{ color: #e2e2e2!important; }.footer_top{background-color:#f26722;}.footer_bottom, .footer_bottom p{ color: #ffffff!important; }.footer_bottom {border-top-color: #ea8857!important; }.footer_bottom{background-color:#f26722;}body{}body h2{}body h3{}body h4{}body h5{}body h6{}
</style>
<link rel="stylesheet" id="style-css" href="<?php echo e(asset('css/style_1.css')); ?>" type="text/css" media="all">
<link rel="stylesheet" id="js_composer_front-css" href="<?php echo e(asset('css/js_composer.min.css')); ?>" type="text/css" media="all">
<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>" id="jquery-core-js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-migrate.min.js')); ?>" id="jquery-migrate-js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/rbtools.min.js')); ?>" id="tp-tools-js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/rs6.min.js')); ?>" id="revmin-js"></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='https://www.sbsc.com/wp-content/themes/nt-antique/js/framework/html5shiv.js?ver=3.7.2' id='html5shiv-js'></script>
<![endif]-->
<!--[if lt IE 9]>
<script type='text/javascript' src='https://www.sbsc.com/wp-content/themes/nt-antique/js/framework/respond.min.js?ver=1.4.2' id='respond-js'></script>
<![endif]-->
<link rel="https://api.w.org/" href="https://www.sbsc.com/wp-json/">
<link rel="alternate" type="application/json" href="https://www.sbsc.com/wp-json/wp/v2/pages/261">
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.sbsc.com/wp-includes/wlwmanifest.xml">
<meta name="generator" content="WordPress 6.1.1">
<link rel="canonical" href="https://www.sbsc.com/">
<link rel="shortlink" href="https://www.sbsc.com/">
<link rel="alternate" type="application/json+oembed" href="https://www.sbsc.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.sbsc.com%2F">
<link rel="alternate" type="text/xml+oembed" href="https://www.sbsc.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fwww.sbsc.com%2F&format=xml">
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
<meta name="generator" content="Powered by Slider Revolution 6.3.9 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface.">
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
<style type="text/css" data-type="vc_custom-css">.cs-class{
    border: 1px solid #f26722;
    padding: 20px 20px;
    background: #fff;
    display: flex;
    flex-wrap: wrap;
    align-content: space-around;
    height: 350px;
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1629910778821{margin-bottom: 0px !important;padding-bottom: 0px !important;}.vc_custom_1631790243755{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1627322823615{padding-top: 150px !important;padding-bottom: 150px !important;background-image: url(images/servicesBG.jpg) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1630665276070{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1627031206823{padding-top: 150px !important;padding-bottom: 150px !important;background-image: url(images/clientFeedBg.jpg) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1630665276070{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1631796280262{padding-top: 150px !important;padding-bottom: 150px !important;background-image: url(images/contactUsBGNew2-1.jpg) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1629910639097{margin-bottom: 0px !important;padding-bottom: 0px !important;}.vc_custom_1629910395611{margin-bottom: 0px !important;padding-bottom: 0px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1627409329150{padding-bottom: 26px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1627409338222{padding-bottom: 26px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1627409229718{padding-bottom: 26px !important;}.vc_custom_1630501026808{margin-bottom: 0px !important;}.vc_custom_1633078776845{background-image: url(images/Oval-feedback-1.png) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1634464870273{margin-bottom: 32px !important;}.vc_custom_1634463895709{padding-bottom: 26px !important;}.vc_custom_1634462264930{margin: 0px !important;padding: 0px !important;}.vc_custom_1634463999217{margin-top: 0px !important;margin-right: 0px !important;margin-bottom: 0px !important;margin-left: 0px !important;}.vc_custom_1634462302454{margin: 0px !important;padding: 0px !important;}.vc_custom_1634462315299{margin: 0px !important;padding: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
<style>#rev_slider_8_1_wrapper { height: 700px }</style></head>
<body class="home page-template page-template-one-page-template page-template-one-page-template-php page page-id-261 mega-menu-primary ninetheme-shortcode-plugin-version- light_skin wpb-js-composer js-comp-ver-6.7.0 vc_responsive" data-spy="scroll" data-target=".navbar-default" data-offset="100">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-dark-grayscale"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0 0.49803921568627"/><fefuncg type="table" tableValues="0 0.49803921568627"/><fefuncb type="table" tableValues="0 0.49803921568627"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-grayscale"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0 1"/><fefuncg type="table" tableValues="0 1"/><fefuncb type="table" tableValues="0 1"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-yellow"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0.54901960784314 0.98823529411765"/><fefuncg type="table" tableValues="0 1"/><fefuncb type="table" tableValues="0.71764705882353 0.25490196078431"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-red"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0 1"/><fefuncg type="table" tableValues="0 0.27843137254902"/><fefuncb type="table" tableValues="0.5921568627451 0.27843137254902"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-midnight"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0 0"/><fefuncg type="table" tableValues="0 0.64705882352941"/><fefuncb type="table" tableValues="0 1"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-magenta-yellow"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0.78039215686275 1"/><fefuncg type="table" tableValues="0 0.94901960784314"/><fefuncb type="table" tableValues="0.35294117647059 0.47058823529412"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-green"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0.65098039215686 0.40392156862745"/><fefuncg type="table" tableValues="0 1"/><fefuncb type="table" tableValues="0.44705882352941 0.4"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-orange"><fecolormatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 "/><fecomponenttransfer color-interpolation-filters="sRGB"><fefuncr type="table" tableValues="0.098039215686275 1"/><fefuncg type="table" tableValues="0 0.66274509803922"/><fefuncb type="table" tableValues="0.84705882352941 0.41960784313725"/><fefunca type="table" tableValues="1 1"/></fecomponenttransfer><fecomposite in2="SourceGraphic" operator="in"/></filter></defs></svg>                        <div id="preloader">
                <div class="loader01"></div>
            </div>
            
<div id="main-content" class="main-content">
	<header id="header">
		<nav class="navbar-default" data-scroll-header>
			<div class="container">
				<div class="navbar-header">

					<!-- Button visible at the top-right corner of
					extra-small devices (mobiles and iPads) -->

					<!-- Navigation bar to call defferent pages,
				not visible on extra-small devices -->

				<div class="collapsed navbar-collapse" id="navbar">
					<div id="mega-menu-wrap-primary" class="mega-menu-wrap"><div class="mega-menu-toggle"><div class="mega-toggle-blocks-left"></div><div class="mega-toggle-blocks-center"></div><div class="mega-toggle-blocks-right"><div class="mega-toggle-block mega-menu-toggle-animated-block mega-toggle-block-1" id="mega-toggle-block-1"><button aria-label="Toggle Menu" class="mega-toggle-animated mega-toggle-animated-slider" type="button" aria-expanded="false">
                  <span class="mega-toggle-animated-box">
                    <span class="mega-toggle-animated-inner"></span>
                  </span>
                </button></div></div></div><ul id="mega-menu-primary" class="mega-menu max-mega-menu mega-menu-horizontal mega-no-js" data-event="hover" data-effect="fade_up" data-effect-speed="200" data-effect-mobile="disabled" data-effect-speed-mobile="0" data-mobile-force-width="body" data-second-click="go" data-document-click="collapse" data-vertical-behaviour="standard" data-breakpoint="768" data-unbind="true" data-mobile-state="collapse_all" data-hover-intent-timeout="300" data-hover-intent-interval="100"><li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-current-menu-item mega-current_page_item mega-menu-item-home mega-align-bottom-left mega-menu-flyout mega-menu-item-1203" id="mega-menu-item-1203"><a class="mega-menu-link" href="/" tabindex="0">Home</a></li><li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-menu-megamenu mega-align-bottom-left mega-menu-grid mega-item-align-right mega-menu-item-752" id="mega-menu-item-752"><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">Services<span class="mega-indicator"></span></a>
<ul class="mega-sub-menu">
<li class="mega-menu-row" id="mega-menu-752-0">
	<ul class="mega-sub-menu">
<li class="mega-menu-column mega-menu-columns-6-of-12" id="mega-menu-752-0-0">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-753" id="mega-menu-item-753"><a class="mega-menu-link" href="application-development">Application Development</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-825" id="mega-menu-item-825"><a class="mega-menu-link" href="mobile-application-development">Mobile Application Development</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-929" id="mega-menu-item-929"><a class="mega-menu-link" href="application-support">Application Support</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-942" id="mega-menu-item-942"><a class="mega-menu-link" href="quality-assurance-testing">Quality Assurance Testing</a></li>
</ul>
</li><li class="mega-menu-column mega-menu-columns-6-of-12" id="mega-menu-752-0-1">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-956" id="mega-menu-item-956"><a class="mega-menu-link" href="program-project-management">Program & Project Management</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-967" id="mega-menu-item-967"><a class="mega-menu-link" href="business-intelligence-competency">Business Intelligence Competency</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1335" id="mega-menu-item-1335"><a class="mega-menu-link" href="consultation-services">Consultation Services</a></li>	
</ul>
</li>	</ul>
</li></ul>
</li>
<li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-menu-megamenu mega-align-bottom-left mega-menu-grid mega-menu-item-896" id="mega-menu-item-896"><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">Frameworks<span class="mega-indicator"></span></a>
<ul class="mega-sub-menu">
<li class="mega-menu-row" id="mega-menu-896-0">
	<ul class="mega-sub-menu">
<li class="mega-menu-column mega-menu-columns-6-of-12" id="mega-menu-896-0-0">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-897" id="mega-menu-item-897"><a class="mega-menu-link" href="inventory-management-system">Inventory Management System</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-975" id="mega-menu-item-975"><a class="mega-menu-link" href="computerized-maintenance-management-system">Computerized Maintenance Management System</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-978" id="mega-menu-item-978"><a class="mega-menu-link" href="workflow-management-system">Workflow Management System</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-981" id="mega-menu-item-981"><a class="mega-menu-link" href="emergency-department-information-system">Emergency Department Information System</a></li>		
</ul>
</li><li class="mega-menu-column mega-menu-columns-6-of-12" id="mega-menu-896-0-1">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-984" id="mega-menu-item-984"><a class="mega-menu-link" href="healthcare-vendor-management-system">Healthcare Vendor Management System</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-987" id="mega-menu-item-987"><a class="mega-menu-link" href="online-market-place">Online Market Place</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-990" id="mega-menu-item-990"><a class="mega-menu-link" href="portfolio-management-office-too">Portfolio Management Office Tool</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-993" id="mega-menu-item-993"><a class="mega-menu-link" href="electronic-transcript-management-system">Electronic Transcript Management System</a></li>		
</ul>
</li>	</ul>
</li></ul>
</li>
<li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-994" id="mega-menu-item-994"><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">Industries<span class="mega-indicator"></span></a>
<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1011" id="mega-menu-item-1011"><a class="mega-menu-link" href="finance">Finance</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1018" id="mega-menu-item-1018"><a class="mega-menu-link" href="retail">Retail</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1021" id="mega-menu-item-1021"><a class="mega-menu-link" href="healthcare">Healthcare</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1014" id="mega-menu-item-1014"><a class="mega-menu-link" href="education">Education</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1025" id="mega-menu-item-1025"><a class="mega-menu-link" href="oil-and-gas">Oil and Gas</a></li>
</ul>
</li><li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-menu-megamenu mega-align-bottom-left mega-menu-grid mega-menu-item-1029" id="mega-menu-item-1029"><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">About Us<span class="mega-indicator"></span></a>
<ul class="mega-sub-menu">
<li class="mega-menu-row" id="mega-menu-1029-0">
	<ul class="mega-sub-menu">
<li class="mega-menu-column mega-menu-columns-4-of-12" id="mega-menu-1029-0-0">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-widget widget_text mega-menu-item-text-10" id="mega-menu-item-text-10">			<div class="textwidget"><h4>COMPANY OVERVIEW</h4>
</div>
		</li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1030" id="mega-menu-item-1030"><a class="mega-menu-link" href="meet-our-team">Meet our Team</a></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1052" id="mega-menu-item-1052"><a class="mega-menu-link" href="board-of-advisors">Board of Advisors</a></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1062" id="mega-menu-item-1062"><a class="mega-menu-link" href="our-partnerships">Our Partnerships</a></li>		
	</ul>
</li><li class="mega-menu-column mega-menu-columns-4-of-12" id="mega-menu-1029-0-1">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-widget widget_text mega-menu-item-text-11" id="mega-menu-item-text-11">			<div class="textwidget"><h4>MORE ABOUT US</h4>
</div>
		</li><li class="mega-menu-item mega-menu-item-type-widget widget_custom_html mega-menu-item-custom_html-3" id="mega-menu-item-custom_html-3"><div class="textwidget custom-html-widget"></div></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1137" id="mega-menu-item-1137"><a class="mega-menu-link" href="mission-vision-values">Mission, Vision & Values</a></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1123" id="mega-menu-item-1123"><a class="mega-menu-link" href="corporate-social-responsibility">Corporate Responsibility</a></li>		</ul>
</li><li class="mega-menu-column mega-menu-columns-4-of-12" id="mega-menu-1029-0-2">
		<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-widget widget_text mega-menu-item-text-12" id="mega-menu-item-text-12">			<div class="textwidget"><h4>GLOBAL PRESENCE</h4>
</div>
		</li><li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1427" id="mega-menu-item-1427"><a class="mega-menu-link" href="global-locations">Global Locations</a></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1136" id="mega-menu-item-1136"><a class="mega-menu-link" href="sbsc-india">SBSC India</a></li>
		<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1150" id="mega-menu-item-1150"><a class="mega-menu-link" href="sbsc-africa">SBSC Africa</a></li>		</ul>
</li>	</ul>
</li><li class="mega-menu-row" id="mega-menu-1029-1">
	<ul class="mega-sub-menu">
<li class="mega-menu-column mega-menu-columns-3-of-12" id="mega-menu-1029-1-0"></li>	</ul>
</li></ul>
</li><li class="mega-menu-item mega-menu-item-type-custom mega-menu-item-object-custom mega-menu-item-has-children mega-align-bottom-left mega-menu-flyout mega-menu-item-1174" id="mega-menu-item-1174"><a class="mega-menu-link" href="#" aria-haspopup="true" aria-expanded="false" tabindex="0">Careers<span class="mega-indicator"></span></a>
<ul class="mega-sub-menu">
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1176" id="mega-menu-item-1176"><a class="mega-menu-link" href="usa">USA</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1198" id="mega-menu-item-1198"><a class="mega-menu-link" href="india">India</a></li>
<li class="mega-menu-item mega-menu-item-type-post_type mega-menu-item-object-page mega-menu-item-1201" id="mega-menu-item-1201"><a class="mega-menu-link" href="africa">Africa</a></li></ul>
</li></ul></div>					

					<!-- Socia icons -->
										<!-- End of .social -->
				</div>
				<!-- End of #navbar -->

					<!-- default static nav logo -->
					
<a href="/" class="brand img-logo"><img class="brand-logo" src="images/SBSC-logo-Colour.png" alt="SBSC"></a> 
<!-- Your Logo -->
												
					<!-- sticky logo -->
																								<a href="https://www.sbsc.com/" class="sticky-logo brand img-logo"><img class="brand-logo" src="images/SBSC-logo-Colour.png" alt="SBSC"></a> <!-- Your Logo -->
															</div>
				<!-- End of .navbar-header -->

				
			</div>
			<!-- End of .container -->
		</nav>
		<!-- End of nav -->
	</header>
	<!-- End of header -->

<?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views////SBSC/header.blade.php ENDPATH**/ ?>