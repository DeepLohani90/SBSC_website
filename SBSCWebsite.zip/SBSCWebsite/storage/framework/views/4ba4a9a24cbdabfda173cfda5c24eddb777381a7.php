<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="/">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Electronic Transcript</span> Management System</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>Information is the most important asset for economic development in the 21st century. Through its capacity to augment productivity, it increasingly constitutes the foundation of a country’s competitive advantage, particularly in a developing country. There are currently various government reforms and initiatives aimed at improving educational system. Considerable progress can be made in a nation through careful engineering of the educational process. Currently there are many challenges being faced in manual processing and exchanging of transcripts.</p>
<p>SBSC designed Script to merge the benefits of technology with the growing demands within the educational sector. This technology platform processes transcripts/certificates request while maintaining all the required international privacy, security and compliance standards.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Electronic Transcript Generation<br>
</b>Enables universities/institutions to expedite automated processing of transcripts/ certificates. This also includes the flexibility to generate customized transcript/certificate templates.</p>
<p class="p1"><b>Electronic Transcript Exchange<br>
</b>To enable universities, and other tertiary institutions to exchange electronic transcripts with participating tertiary institutions via secure network and automated e-mail acknowledgements / alerts.</p>
<p><b>Transcript Ordering<br>
</b>Allows students/parents and alumni of participating tertiary institutions to order transcripts online and make payments using a Secured Payment Gateway.</p>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Reduce Cost<br>
</b>Transcript/certificates are stored and maintained digitally, reducing costs associated processing, generating, printing.</p>
<p class="p1"><b>Save Time<br>
</b>Administrative efforts are noticeably reduced by our platform, for processing Transcripts / certificates and addressing to exchange requests of students.</p>
<p class="p1"><b>Increased Access<br>
</b>Requests are not limited to business hours of the institutions. The online solution can process requests 24×7.</p>
<p><b>Instant Delivery<br>
</b>Transcripts/certificates are instantly delivered to academic institutions, prospective employers and other recipients via our secure integrated Electronic Transcript Delivery Network.</p>

		</div>
	</div>
</div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/new_site/resources/views/SBSC/electronic-transcript-management-system.blade.php ENDPATH**/ ?>