<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Online</span> Market Place</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>We are currently experiencing a global shopping revolution, where online purchases are growing exponentially. This growth can be characterized by strong consumer demands and the increasing types of goods available. Retailers have adapted how they do business and have created online marketplaces. These marketplaces encompass the entire sales channels for retailers worldwide.</p>
<p>SBSC has developed a flexible, scalable and ready to deploy online shopping platform that helps your business to go beyond geographical boundaries and create a larger customer base. Our platform caters to both B2B and B2C needs of this business model. It enables your business to sell your products and enhance the customer encounters with convenient and secure purchasing experiences. Our analytical reports module will give you an effective business insight and will also help you in your business decision making.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Business Module<br>
</b>Supports both B2B and B2C, where other brands can register to sell their products and customers can purchase multiple products.</p>
<p class="p1"><b>Payment Module<br>
</b>Supports multiple payment methods like cash, cheque, cards.</p>
<p class="p1"><b>Category Management<br>
</b>Helps to create and manage various categories of products. Also provides the flexibility to track inventories and purchases under the categories..</p>
<p class="p1"><b>Marketing Management<br>
</b>Enhances your marketing through banner display management and newsletter/promotion management to retain your customers.</p>
<p class="p1"><b>Order management and Tracking<br>
</b>Enables you to manage all your orders centrally. Empowers the customer to track the status of the orders.</p>
<p class="p1"><b>Dashboard<br>
</b>Make informed business decision through analytical reports around payments, inventory and customer data.</p>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>24&#215;7<br>
</b>Time constraints and problems with varying international trading hours are removed. Flexibility to conduct business around the clock and catapult your business to newer heights.</p>
<p class="p1"><b>Convenient<br>
</b>Offers an easy way to compare prices and products from a single source rather than spending time contacting each individual supplier.</p>
<p class="p1"><b>Beyond Boundaries<br>
</b>Enables you to increase your customer base because you are not constrained by geography. There are greater opportunities for suppliers and buyers to establish new trading partnerships.</p>
<p class="p1"><b>Economical<br>
</b>It acts as as powerful marketing and communicating tool – an additional sales channel to market and sell products thereby reduces your marketing cost by using our platform.</p>
<p class="p1"><b>Secure<br>
</b>Transactions are secured with technology. Easy and secured payment processing makes your customers buying experience effortless.</p>
<p class="p1"><b>Transparency<br>
</b>It provides greater transparency in the purchasing process since availability, prices and stock levels are all accessible in an open environment.</p>

		</div>
	</div>
</div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/online-market-place.blade.php ENDPATH**/ ?>