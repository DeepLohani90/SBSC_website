<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Emergency Department</span> Information System</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>Currently, statistics project an increasing number of visits to Emergency Departments (EDs). This spike in patient intake can lead to errors in processing patients due to poor management systems and can negatively impact quality of service and trust. Improper workflows, failure in managing patient discharges, interdepartmental miscommunication and delayed accessibility of patient records are pain points that are effecting today’s EDs. These issues can be better managed with the use of a powerful solution that is simple to learn and easy to use.</p>
<p>Our Emergency Department Information System (EDIS) provides the solution for a hospital’s emergency care needs. EDIS focuses on process optimization, from patient registration through patient discharge. It facilitates and improves patients tracking and medical record accessibility. It also enhances data accuracy by leveraging a robust reporting system.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Triage<br>
</b>Easily captures patient vitals. Documents patient medical history. Displays active allergy and medication history.</p>
<p class="p1"><b>Assignment<br>
</b>Multiple ways of assigning a patient, doctor or nurse in single screen. Auto assignment of empty beds. Manage shift assignments.</p>
<p class="p1"><b>Assessment<br>
</b>Capture and submit patient’s assessment information (health history &amp; ROS). Pre-populates initial triage information to physician to perform triage validation.</p>
<p class="p1"><b>Order Management<br>
</b>Create and place multiple orders at a time against a patient like; Medication, Laboratory orders. Perform respective approvals / rejections. Track the order status.</p>
<p class="p1"><b>Patient Billing<br>
</b>Details of the bills against the orders generated for patient. Generate Invoice. Payment Gateway for online bill payment. View payment history.</p>
<p class="p1"><b>Patient Discharge<br>
</b>Capability to Discharge /Disposition individual patient on basis of assessment. Once the patient is discharged, any change in patient’s assessment information is restricted.</p>
<p class="p1"><b>Alert &amp; Notification<br>
</b>On successful patient assignment/un-assignment system sends alert message to respective users. Capability to send message to multiple users within the facility.</p>
<p class="p1"><b>Reports / Dashboard<br>
</b>Provides reports like – Daily Registration, Emergency Triage Statistics, Radiology and Laboratory Statistics, Patient Provider Assignment, Room Utilization.</p>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Effective Management<br>
</b>Automates functions (registration, triage, patient tracking, orders/results, documentation and discharge), resulting in faster patient throughput and enhanced staff communication, leading to better interaction across departments, better management of workflow and improved clinical quality measurements..</p>
<p class="p1"><b>Increase Clinical Accuracy<br>
</b>Expedites capturing key patient information and access to patient records, physician notes, diagnostic studies and care guidelines which enables physicians to make better and faster clinical decisions.</p>
<p class="p1"><b>Easy Information Exchange<br>
</b>Ability to pull electronic medical records across systems, helping to improve efficiency, accuracy, timeliness, and overall care. Improves system reliability by ensuring legible communication, facilitated retrieval of past information, and access to computerized physician order entry to aid in clinical decision support.</p>

		</div>
	</div>
</div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/emergency-department-information-system.blade.php ENDPATH**/ ?>