<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629383369923{margin-bottom: 50px !important;}.vc_custom_1629386712994{margin-top: 0px !important;margin-bottom: 100px !important;padding-top: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629383369923">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Global Presence</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Global</span> Locations</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629386712994"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 style="text-align: center;">At SBSC, we deliver differently&#8230;</h4>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 class="vc_custom_heading vc_custom_1486718718621">Main Offices</h4>

		</div>
	</div>
<section class="contact"><div class="container"><div class="form_area clearfix"></div><div class="contact_info"><div class="row"><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>1703 SW Commerce Dr., Suite 19,<br>
Bentonville, AR 72712<br>
<strong>Phone:</strong> 877.213.3835, <strong>Fax:</strong> 212.358.2575
<p> </p><p> </p></h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>2911 Turtle Creek Blvd<br>
Suite 300. Dallas, TX 75219<br>
<strong>Phone:</strong> 877.213.3835, <strong>Fax:</strong> 212.358.2575
<p>&nbsp;</p><p>&nbsp;</p></h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>14 Wall Street 20th Floor,<br>
New York, NY 10005<br>
<strong>Phone:</strong> 877.213.3835, <strong>Fax:</strong> 212.358.2575</h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>Atlantic Station, 201 17th Street, Suite 300,<br>
Atlanta, Georgia 30363<br>
<strong>Phone:</strong> 877.213.3835, <strong>Fax:</strong> 212.358.2575</h3></div></div></div></div></section>
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 class="vc_custom_heading vc_custom_1486718734471">International offices</h4>

		</div>
	</div>
<section class="contact"><div class="container"><div class="form_area clearfix"></div><div class="contact_info"><div class="row"><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>Elixir Business Park, 3rd Floor,<br>
Plot no. 15-A, Sector – 127<br>
Noida – 201304<br>
<strong>India</strong>
<p> </p><p> </p></h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>The Masterpiece. 2nd Floor,<br>
Sector-54, Golf Course Road<br>
Gurgaon. Haryana – 122002<br>
<strong>India</strong>
<p> </p><p> </p></h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>14A Karimu Ikotun,<br>
Victoria Island, Lagos,<br>
<strong>Nigeria</strong></h3></div><div class="col-sm-6"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>Software Business Solutions Ghana Ltd.<br>
115 Airport West Link Airport Residential Area,<br>
Accra, <strong>Ghana</strong></h3></div><div class="col-sm-6" style="margin-top: 60px;"><i class="fas fa-map-marker-alt" style=" color:#f26722!important;" aria-hidden="true"></i><h3>KT Software Solutions <br>
115 Standard Chartered Tower,  Level 5 Emaar Square Downtown Burj Khalifa, Dubai <strong>UAE</strong></h3>
<img decoding="async" class="aligncenter" src="images/KTSoftwareSolutions.jpg">
</div></div></div></div></section>

<p></p></div></div></div><br>
</div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/global-locations.blade.php ENDPATH**/ ?>