<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style type="text/css" data-type="vc_custom-css">.container-custom{width:1140px;}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1629449092811{margin-bottom: 100px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629386986220{margin-bottom: 50px !important;}.vc_custom_1629441601791{margin-top: 0px !important;margin-bottom: 0px !important;padding-top: 0px !important;}.vc_custom_1629449497963{margin-bottom: 0px !important;}.vc_custom_1629449566333{margin-bottom: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629386986220">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Career</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Career</span> USA</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629441601791"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p>At SBSC we provide holistic employment experience with flexibility to balance both your professional and personal life along with the joy of working on latest technologies. Discover world of innovation, learning, growth and equal opportunities with us. Looking forward for reshaping your career with us. Listed below are some current opening we are hiring for. Can’t find the vacancy you seek?.. No Worries .. Mail your CV to us at <a href="mailto:careers@sbsc.com">careers@sbsc.com</a> and we will get back to you.</p>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 class="vc_custom_heading vc_custom_1492689453089">Current Job Openings</h4>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="container container-custom"><div class="vc_row wpb_row vc_row-fluid cusContainer vc_custom_1629449092811"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_tta-container" data-vc-action="collapseAll"><div class="vc_general vc_tta vc_tta-accordion vc_tta-color-blue vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-all-clickable"><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel" id="1629437358260-7757595d-33b6" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629437358260-7757595d-33b6" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-headset"></i><span class="vc_tta-title-text">Support Analyst</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629449497963">
		<div class="wpb_wrapper">
			<p><strong>Location:</strong> Software Business Solutions Consulting – Bentonville, AR<br>
<strong>Job type:</strong> Contract</p>
<p><strong>Overview:</strong></p>
<p>Working under minimal supervision, help desk analysts receives tickets and inquiries, provides support in accordance with established processes and document incidents and remedies. They also escalate complex incidents to next-level support personnel.</p>
<p><strong>Daily tasks:</strong></p>
<ul class="ms-cus-ul">
<li>Troubleshoot, diagnose, and resolve problems related to computer software and operating systems</li>
<li>Research various issues and come up with a solution for each</li>
<li>Document resolutions and conversations to create logs and wiki pages that can be referenced by other technicians for troubleshooting and training purposes</li>
<li>Track, route, and redirect tickets to correct resources</li>
<li>Walk customers through problem solving process</li>
<li>Follow up with customers, provide feedback and see tickets through to resolution</li>
<li>Utilize excellent customer service skills and exceed customers’ expectations</li>
<li>Recommend procedure modifications or improvements</li>
<li>Preserve and grow your knowledge of help desk procedures, products and services</li>
</ul>
<p><strong>Requirements:</strong></p>
<ul class="ms-cus-ul">
<li>Must have excellent communication skills and be able to translate technical knowledge into measurable results</li>
<li>Proven working experience in providing help desk support</li>
<li>Proficiency in English</li>
<li>Working knowledge of incident ticketing software, operating systems, and remote control software *Strong client-facing and communication skills</li>
<li>Advanced troubleshooting and multi-tasking skills *Customer service oriented</li>
<li>BS degree in Information Technology, Computer Science or equivalent / AA in Information Technology, Computer Science or equivalent and two years’ experience in Information Technology related fields / or four years’ experience in Information Technology related fields</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply For This Job</a></div></div></div><div class="vc_tta-panel" id="1629448682378-62c948dc-099e" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629448682378-62c948dc-099e" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-binoculars"></i><span class="vc_tta-title-text">Job Description for a Sales Hunter (SH)</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629449566333">
		<div class="wpb_wrapper">
			<p><strong>Location:</strong> Virtual<br>
<strong>Job type:</strong> Contract</p>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>Establish relationships with new customers and secure contracts with new customers that achieve assigned sales quotas and targets (this should be quantified against a calendar schedule)</li>
<li>Drive the entire sales cycle from initial customer engagement to closed sales (and in some cases through delivery and cash receipt as mentioned above)</li>
<li>Prospect for potential customers using various direct methods such as calling and face to face meetings, and indirect methods such as networking (this is often accompanied by an identification of the territory in which the SH will prospect)</li>
<li>Qualify prospects against company criteria for ideal customers and sales</li>
<li>Consult with prospect about business challenges and requirements, as well as the range of options and cost benefits of each.</li>
<li>Maintain a high level of relevant domain knowledge in order to have meaningful conversations with prospects.</li>
<li>Make presentations to senior managers and decision makers</li>
<li>Draft and deliver proposals</li>
<li>Work with technical staff and product specialists where required to address customer requirements</li>
<li>Develop and maintain territory plans which outline how sales targets will be met on an ongoing basis</li>
<li>Develop and maintain key account plans that identify opportunities for company to deliver value, strategic motivators, main stakeholders, buying processes and forecasted sales</li>
<li>Report on sales activity (include desired frequency – daily is ideal for accuracy)</li>
<li>Keep detailed notes on prospect and customer interactions (include frequency – daily is ideal for accuracy)</li>
<li>Provide forecasts on best case and most likely sales volumes over relevant time periods</li>
<li>Work with delivery teams to proactively address problems</li>
<li>Cultivate strong relationships with third party and partner companies that may be required to deliver full solutions to customers</li>
<li>Work with marketing to plan and execute lead generation campaigns</li>
<li>Provide feedback to sales management on ways to decrease the sales cycle, enhance sales, and improve company brand and reputation</li>
<li>Provide feedback to company management on market trends, competitive threats, unmet needs, and opportunities to deliver greater value to customers by extending company offerings</li>
<li>Identify sales support requirements and work with marketing to develop improve sales tools</li>
<li>Be a positive representative of the company and its brand in the marketplace</li>
<li>Conduct all sales activities with the highest degree of professionalism and integrity</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply For This Job</a></div></div></div></div></div></div></div></div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php /**PATH /var/www/html/new_site/resources/views/SBSC/usa.blade.php ENDPATH**/ ?>