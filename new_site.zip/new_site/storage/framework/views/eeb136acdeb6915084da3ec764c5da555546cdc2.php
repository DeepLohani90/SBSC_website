<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_custom-css">.areaPointBG{
    padding: 30px;
    margin: 20px;
    background: #ffffffd1;
}
</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">

	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="/">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Contact</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Contact</span> Us</h1>

		</div>
	</div>

<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>Feedback and questions are always welcome. Let’s get in touch!</p>
<p>What else would you like to know about us? Want to talk about what you need? Fill in the information below and we’ll get back to you right away.</p>

		</div>
	</div>
	<div role="form" class="wpcf7" id="wpcf7-f1377-p1375-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul>
</div>
</div>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<form method="post" action="/">	
	<?php echo csrf_field(); ?>
<div class="container">
 <div class="col-12">
  <div class="row">
    <div class="col-4">
    	<div class="form-group">
      <label for="Name">Name</label>
      <input type="text" name="name" class="form-control" style="font-size: 15px;" required>
  </div>
    </div>
    <div class="col-4">
    	<div class="form-group">
      <label for="Name">Your email</label>
      <input type="email" name="email" class="form-control" style="font-size: 15px;" required>
  </div>
    </div>
    <div class="col-4">
    	<div class="form-group">
      <label for="Name">Your phone</label>
      <input type="tel" name="phone" class="form-control" style="font-size: 15px;" required>
  </div>
    </div>
    </div>
  </div>
  <div class="col-12">
  	<div class="form-group">
  		<label for="message">Message</label>
  		<textarea class="form-control" cols="50" rows="15" style="font-size: 15px;"required></textarea>
  	</div>
  </div>
  <div class="col-4">
  	<input type="submit" name="submit" class="btn btn-primary h-100 p-2" value="Submit" style="font-size: 15px; text-transform: none; letter-spacing: 0px;">
  </div>
</div>
</form>
</div>
</div></div>
</div></div></div></div></div>

</div>

<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/new_site/resources/views/SBSC/contact-us.blade.php ENDPATH**/ ?>