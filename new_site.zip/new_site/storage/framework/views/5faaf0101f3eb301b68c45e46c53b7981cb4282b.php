<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1><?php echo e($mailData['title']); ?></h1>
    <p><?php echo e($mailData['body']); ?></p> 
    <p><?php echo e($mailData['phone']); ?></p> 

    <p>Thank you</p>
</body>
</html><?php /**PATH G:\new_site\resources\views/emails/demoMail.blade.php ENDPATH**/ ?>