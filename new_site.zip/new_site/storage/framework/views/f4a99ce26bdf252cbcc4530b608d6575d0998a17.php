<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
hi this is page <?php echo e($title); ?>

<a href="/">Home </a>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\SBSC\new_site\resources\views/contact.blade.php ENDPATH**/ ?>