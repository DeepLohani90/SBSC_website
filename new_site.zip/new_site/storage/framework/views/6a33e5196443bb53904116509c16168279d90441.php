 <!-- footer starts
    ====================================================== -->
    <footer>
                        <div class="footer_top">
                    <div class="container">
                        <div class="row">
                            <div class="widget widget_text">			<div class="textwidget"><div class="col-sm-12 col-md-3 col-lg-3">
<ul>
<li><h3>Our Services</h3></li>
<li><a href="https://www.sbsc.com/application-development/">Application Development</a></li>
<li><a href="https://www.sbsc.com/mobile-application-development/">Mobile Application Development</a></li>
<li><a href="https://www.sbsc.com/application-support/">Application Support</a></li>
<li><a href="https://www.sbsc.com/quality-assurance-testing/">Quality Assurance Testing</a></li>
<li><a href="https://www.sbsc.com/program-project-management/">Program & Project Management</a></li>
<li><a href="Business Intelligence Competency">Business Intelligence Competency</a></li>
</ul>
</div>
</div>
		</div><div class="widget widget_text">			<div class="textwidget"><div class="col-sm-12 col-md-3 col-lg-3">
<ul>
<li><h3>About Us</h3></li>
<li><a href="https://www.sbsc.com/meet-our-team/">Meet Our Team</a></li>
<li><a href="https://www.sbsc.com/board-of-advisors/">Board Of Advisors</a></li>
<li><a href="https://www.sbsc.com/our-partnerships/">Our Partnerships</a></li>
<li><a href="https://www.sbsc.com/mission-vision-values/">Mission, Vision & Values</a></li>
<li><a href="https://www.sbsc.com/corporate-social-responsibility/">Corporate Responsibility</a></li>
</ul>
</div>
</div>
		</div><div class="widget widget_text">			<div class="textwidget"><div class="col-sm-12 col-md-3 col-lg-3">
<ul class="cWU">
<li><h3>Connect With Us</h3></li>
<li id="menu-item-1159" class="fa fa-envelope menu-item menu-item-type-post_type menu-item-object-page menu-item-1159"><a href="https://www.sbsc.com/contact-us/"> Contact Us</a></li>
<li id="menu-item-879" class="fa fa-facebook-official menu-item menu-item-type-custom menu-item-object-custom menu-item-879"><a target="_blank" href="https://www.facebook.com/pages/Software-Business-Solutions-Consulting/238724149664677" rel="noopener"> Facebook</a></li>
<li id="menu-item-880" class="fa fa-twitter menu-item menu-item-type-custom menu-item-object-custom menu-item-880"><a target="_blank" href="https://twitter.com/sbscglobal" rel="noopener"> Twitter</a></li>
<li id="menu-item-882" class="fa fa-linkedin menu-item menu-item-type-custom menu-item-object-custom menu-item-882"><a target="_blank" href="https://www.linkedin.com/company/3777235" rel="noopener"> LinkedIn</a></li>
</ul>
</div></div>
		</div><div class="widget widget_text">			<div class="textwidget"><div class="col-sm-12 col-md-3 col-lg-3">
<ul>
<li><h3>Career</h3></li>
<li><a href="https://www.sbsc.com/usa/">USA</a></li>
<li><a href="https://www.sbsc.com/india/">India</a></li>
<li><a href="https://www.sbsc.com/africa/">Africa</a></li>
</ul>
</div>
</div>
		</div>                        </div>
                        <!-- End of .row -->
                    </div>
                    <!-- End of .container -->
                </div>
                <!-- End of .footer_top -->
                                        <div class="text-center footer_bottom">
                <p>Copyright 2021. All Rights Reserved SBSC</p>            </div>
                <!-- End of footer_bottom -->
    </footer>
    <!-- End of footer -->
    <script type="text/html" id="wpb-modifications"></script><link href="https://fonts.googleapis.com/css?family=Roboto:400%7CMontserrat:700%2C400%2C800%2C300%2C600" rel="stylesheet" property="stylesheet" media="all" type="text/css">

		<script type="text/javascript">
		if(typeof revslider_showDoubleJqueryError === "undefined") {
			function revslider_showDoubleJqueryError(sliderID) {
				var err = "<div class='rs_error_message_box'>";
				err += "<div class='rs_error_message_oops'>Oops...</div>";
				err += "<div class='rs_error_message_content'>";
				err += "You have some jquery.js library include that comes after the Slider Revolution files js inclusion.<br>";
				err += "To fix this, you can:<br>    1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on";
				err += "<br>    2. Find the double jQuery.js inclusion and remove it";
				err += "</div>";
			err += "</div>";
				var slider = document.getElementById(sliderID); slider.innerHTML = err; slider.style.display = "block";
			}
		}
		</script>
<link rel="stylesheet" id="vc_tta_style-css" href="css/js_composer_tta.min.css" type="text/css" media="all">
<script type="text/javascript" src="js/regenerator-runtime.min.js" id="regenerator-runtime-js"></script>
<script type="text/javascript" src="js/wp-polyfill.min.js" id="wp-polyfill-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.sbsc.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="js/index.js" id="contact-form-7-js"></script>
<script type="text/javascript" src="js/comment-reply.min.js" id="comment-reply-js"></script>
<script type="text/javascript" src="js/jquery.nav.js" id="jquery-nav-js"></script>
<script type="text/javascript" src="js/bootstrap.min.js" id="bootstrap-js"></script>
<script type="text/javascript" src="js/jquery.waypoints.min.js" id="waypoints-js"></script>
<script type="text/javascript" src="js/wow.min.js" id="wow-js"></script>
<script type="text/javascript" src="js/imagesLoaded.min.js" id="imagesLoaded-js"></script>
<script type="text/javascript" src="js/main.js" id="nt-antique-main-js"></script>
<script type="text/javascript" id="nt-antique-onepagenav-set-js-extra">
/* <![CDATA[ */
var onepagenavprefix = {"topoffset":"80"};
/* ]]> */
</script>
<script type="text/javascript" src="js/onepagenav-set.js" id="nt-antique-onepagenav-set-js"></script>
<script type="text/javascript" src="js/hoverIntent.min.js" id="hoverIntent-js"></script>
<script type="text/javascript" id="megamenu-js-extra">
/* <![CDATA[ */
var megamenu = {"timeout":"300","interval":"100"};
/* ]]> */
</script>
<script type="text/javascript" src="js/maxmegamenu.js" id="megamenu-js"></script>
<script type="text/javascript" src="js/js_composer_front.min.js" id="wpb_composer_front_js-js"></script>
<script type="text/javascript" src="js/vc-accordion.min.js" id="vc_accordion_script-js"></script>
<script type="text/javascript" src="js/vc-tta-autoplay.min.js" id="vc_tta_autoplay_script-js"></script>
<script type="text/javascript" src="js/vc-tabs.min.js" id="vc_tabs_script-js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js" id="wpforms-validation-js"></script>
<script type="text/javascript" src="js/mailcheck.min.js" id="wpforms-mailcheck-js"></script>
<script type="text/javascript" src="js/wpforms.js" id="wpforms-js"></script>
<script type="text/javascript">
/* <![CDATA[ */
var wpforms_settings = {"val_required":"This field is required.","val_email":"Please enter a valid email address.","val_email_suggestion":"Did you mean {suggestion}?","val_email_suggestion_title":"Click to accept this suggestion.","val_email_restricted":"This email address is not allowed.","val_number":"Please enter a valid number.","val_number_positive":"Please enter a valid positive number.","val_confirm":"Field values do not match.","val_checklimit":"You have exceeded the number of allowed selections: {#}.","val_limit_characters":"{count} of {limit} max characters.","val_limit_words":"{count} of {limit} max words.","val_recaptcha_fail_msg":"Google reCAPTCHA verification failed, please try again later.","val_empty_blanks":"Please fill out all blanks.","uuid_cookie":"","locale":"en","wpforms_plugin_url":"https:\/\/www.sbsc.com\/wp-content\/plugins\/wpforms-lite\/","gdpr":"","ajaxurl":"https:\/\/www.sbsc.com\/wp-admin\/admin-ajax.php","mailcheck_enabled":"1","mailcheck_domains":[],"mailcheck_toplevel_domains":["dev"],"is_ssl":"1"}
/* ]]> */
</script>


</body></html><?php /**PATH G:\SBSC\new_site\resources\views////SBSC/footer.blade.php ENDPATH**/ ?>