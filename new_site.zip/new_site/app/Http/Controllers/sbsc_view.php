<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class sbsc_view extends Controller
{
    //
}
