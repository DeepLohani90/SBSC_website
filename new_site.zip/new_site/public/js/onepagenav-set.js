	jQuery(document).ready(function() {
		"use strict"; 

		jQuery('.nav.navbar-nav li').removeClass('active');
		
		var top__offset = onepagenavprefix.topoffset;//default 10'
		var topoffsetfinal = parseInt(top__offset);
		if( !!topoffsetfinal ){var offset_number = topoffsetfinal;}else{ var offset_number = 80;}

		var top_offset = jQuery('.navbar-default.fixed_top').height() + offset_number;  // get height of fixed navbar
		
		jQuery('.nav.navbar-nav').onePageNav({
			currentClass: 'current',
			scrollOffset: top_offset,
			changeHash: false,
			scrollSpeed: 750,
			scrollThreshold: 0.5,
			filter: ':not(.dropdown-toggle)',
			easing: 'swing',
			begin: function() {
				jQuery(".collapse.in").removeClass("in");
			},
			end: function() {

			}
		});

	});