@include('../SBSC/header')
<style type="text/css" data-type="vc_custom-css">@media screen and (max-width: 767px){
    .bgHeight100 {display:none;}
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1630573140640{margin-right: 0px !important;padding-right: 0px !important;background-image: url(images/mobileApplicationSupport.jpg) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628692010160{margin-left: 0px !important;padding-left: 0px !important;}.vc_custom_1628698095642{margin-top: 55px !important;}.vc_custom_1629191554898{margin-bottom: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-5"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Services</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Application</span> Support</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<h2>How SBSC Help</h2>
<p class="p1">SBSC’s Application Support Services manages the operation, maintenance, versioning and upgrading of an application throughout its lifecycle.  Our approach is geared towards providing optimal application performance to meet or exceed stakeholder benchmarks. Our main focus is to provide exceptional service to application owners such as executive level personnel, who use information to assist with productivity, financial and control decisions. Our support also extends to the application developers, managers and IT enterprise personnel who are responsible for the development, deployment and maintenance of an application as well as the end-users and personnel who are the most impacted by the security, privacy, versioning and the overall usability of an application and its modules.</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-7"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="vc_row wpb_row vc_inner bootstrap serviceBoxes">
    <div class="wpb_column vc_column_container vc_col-sm-6">
    <div class="vc_row wpb_row vc_inner bootstrap">
        <div class="wpb_column vc_column_container vc_col-sm-12" style="padding: 0 15px;">
            <div class="serviceBox mr-1" style="min-height: 312px;">
                <img src="images/Level1Functions.png">
                <h3>Level 1 Functions</h3>
                <p>
                    <ul class="asLevel">
                        <li>Password resets</li>
                        <li>Basic hardware troubleshooting</li>
                        <li>Unlocking of end user accounts</li>
                        <li>Basic connectivity troubleshooting</li>
                        <li>Basic account administration</li>
                        <li>Escalation to levels 2 & 3</li>
                    </ul>
                </p>
              </div>
        </div>
        <div class="wpb_column vc_column_container vc_col-sm-12 serviceBoxes" style="padding: 0 15px;">
            <div class="serviceBox mr-1">
              <img src="images/Level3Functions.png">
              <h3>Level 3 Functions</h3>
              <p>
                  <ul class="asLevel">
                      <li>Security and updates</li>
                      <li>Hardware maintenance</li>
                      <li>Installation of approved and licensed software</li>
                      <li>Outage and security incident response</li>
                  </ul>
              </p>
            </div>
          </div>
    </div>
      
    </div>
    <div class="wpb_column vc_column_container vc_col-sm-6">
      <div class="serviceBox ml-1">
        <img src="images/Level2Functions.png">
        <h3>Level 2 Functions</h3>
        <p>
            <ul class="asLevel">
                <li>Set-up of new computers</li>
                <li>Set-up of new users</li>
                <li>Removal of accounts and access for exiting employees</li>
                <li>Training primary help desk support personnel in general help desk issues</li>
                <li>Backup to the primary help desk support</li>
                <li>Updates to primary support personnel</li>
            </ul>
        </p>
      </div>
    </div>
  </div>
		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1630573140640"><div class="wpb_wrapper"></div></div></div><div class="serviceBenefitRight wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628692010160"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original" style="text-align: left;"><span class="orange">Benefits</span> With SBSC</h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Strategic Shift<br>
</b>Our Application Management team permits an organization to free up resources to allow them to re-focus on achieving business objectives without decreasing productivity.</p>
<p class="p1"><b>Fixed Pricing and Lower Cost<br>
</b>Because our costs are negotiated and fixed, partnering with SBSC is less expensive than the costs associated with hiring full time employees.</p>
<p class="p1"><b>Support Availability<br>
</b>Many organizations only offer help desk support during normal business hours, however we provide many flexible options that ensure coverage for any work schedule.</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h1 class="h1Original2" style="text-align: center;">The SBSC <span class="orange">Advantage</span></h1>

		</div>
	</div>
<div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1628698095642"><div class="advantageFlex wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629191554898 sbscAdvantageUL">
		<div class="wpb_wrapper">
			<ul>
<li class="p1">Reduces labor expenses by leveraging remote access diagnose and troubleshoot problems, which significantly improves response time</li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_center">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="406" height="407" src="images/sbscOvelLogo.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy" srcset="images/sbscOvelLogo.jpg 406w, images/sbscOvelLogo-300x300.jpg 300w, images/sbscOvelLogo-150x150.jpg 150w" sizes="(max-width: 406px) 100vw, 406px"></div>
		</figure>
	</div>
</div></div></div><div class="advantageFlex wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  sbscAdvantageUL">
		<div class="wpb_wrapper">
			<ul>
<li class="p1">
<p class="p1">We resolve issues quickly because of our knowledgeable and experience technicians that exceed customer expectations</p>
</li>
</ul>

		</div>
	</div>
</div></div></div></div></div></div></div></div>
</div>
@include('../SBSC/footer')
	