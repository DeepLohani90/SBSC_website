@include('../SBSC/header')
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(../wp-content/uploads/2021/07/sbsc-logo-patternc993.png?id=556) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629382818321{margin-bottom: 50px !important;}.vc_custom_1629381957221{margin-top: 0px !important;margin-bottom: 250px !important;padding-top: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="../wp-content/uploads/2021/09/sbscFav.png" />
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629382818321" >
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="../index.html">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Global Presence</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">SBSC</span> Africa</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629381957221"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<h4 style="text-align: center;">At SBSC, we deliver differently&#8230;</h4>
<p class="p1" style="text-align: center;">Keep our eyes on Africa.</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresencePara wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p>With the best talent in management and technology consulting our goal, as a global organization, is simple: Drive business value by Delivering Solutions Differently to our business partners across the globe. With deep expertise in Financial services, Retail, Travel, Transport, Logistics and Insurance industries, our team has steadily established long lasting relationships and a great reputation in our 5 years of doing business.</p>
<p>In Africa, we are no different. Equipped with a deep “know-how” of the African business terrain and a firm grasp of technology, we are focused on helping our clients Win Big in this dynamic marketplace.</p>
<p>We are deeply rooted in the region and have aggressively built a strong SBSC Africa team from local talent to collaborate with our 5000+ employees across the world- all with the single goal of realizing our promise of driving value in Africa. Driving business value, growing people, and building long lasting relationships is not we do. It’s who we are.</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="469" height="324" src="../wp-content/uploads/2021/08/sbscAfrica.jpg" class="vc_single_image-img attachment-full" alt="" decoding="async" loading="lazy" srcset="https://www.sbsc.com/wp-content/uploads/2021/08/sbscAfrica.jpg 469w, https://www.sbsc.com/wp-content/uploads/2021/08/sbscAfrica-300x207.jpg 300w" sizes="(max-width: 469px) 100vw, 469px" /></div>
		</figure>
	</div>
</div></div></div></div></div></div></div></div>
</div>
@include('../SBSC/footer')
