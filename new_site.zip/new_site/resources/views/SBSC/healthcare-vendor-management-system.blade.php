@include('../SBSC/header')
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1628765986822{margin-right: 0px !important;padding-right: 0px !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1628773766734{margin-left: 0px !important;padding-left: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Frameworks</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Healthcare Vendor</span> Management System</h1>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element  appHeroPara">
		<div class="wpb_wrapper">
			<p>The rapid technological changes and advancements in the health care industry has reshaped not only patient care delivery and the business of health care, but they also require the implementation of new strategies from vendors who support the health care system. Workforce solutions and health care staffing services are greatly impacted by these changes. Consolidation of the health care industry has created increased demand for staffing services. Healthcare providers must fill shifts and vacant positions by using redundant staffing efforts and inefficient manual scheduling procedures.</p>
<p>SBSC’s Healthcare Vendor Management Platform (HVM) simplifies the end to end management of a hospital’s entire supplemental staffing needs and is powered by proprietary bidding and talent ranking engine that ensures medical facilities receive the best-qualified clinical professionals at a true market rate. This customizable solution provides our healthcare clients with a platform specifically tailored to meet their goals and objectives in a short period of time without sacrificing quality or functionality.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid benefitHeight"><div class="bgHeight100 frameworkFeaturesLeft wpb_column vc_column_container vc_col-sm-6 vc_col-has-fill"><div class="vc_column-inner vc_custom_1628765986822"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Features</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1" style="margin-bottom: 0px !important;"><b>Vendor Management</b></p>
<ul style="list-style-type: disc; padding-left: 14px; margin-bottom: 29px;">
<li>Centralized staffing agencies management.</li>
<li>Streamline posting communication.</li>
<li>Efficient scheduling &amp; time management.</li>
<li>Skills portfolio &amp; credential monitoring.</li>
</ul>
<p class="p1"><b>Job &amp; Shift Management<br>
</b>Centralized job board to easily handle all posting, sharing and awarding requirements. Simplified shifts assignment function with alternative shift response ability. Availability search function. Credential alerts and push notifications.</p>
<p class="p1"><b>Time &amp; Billing Management<br>
</b>All time, billing and reconciliation needs in one centralized area. Easy to use time/attendance and time card repository. Create, edit and submit invoices. Simplified reconciliation process.</p>
<p class="p1"><b>Reporting<br>
</b>Provides reports like – Master Schedule, Shift reports, Quality Assurance, Billing &amp; reconciliation, Agency spend, Credentials (Missing, expiring or expired).</p>

		</div>
	</div>
</div></div></div><div class="frameworkBenefitRight sbscLogoBefore wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner vc_custom_1628773766734"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h3 class="h1Original noAfter" style="text-align: center;"><span class="orange">Benefits</span></h3>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p class="p1"><b>Save Time<br>
</b>With an automated process, you don’t have to reach out to each vendor when a staff need arises. Our HVM Platform broadcasts the vacancy to all vendors and returns a list of vetted options. HVM automates time card approval and consolidates invoices. Less time spent on hiring, staffing and invoicing means more time spent on patient care.</p>
<p class="p1"><b>Control Costs<br>
</b>A vendor neutral solution favors cost-competitive vendors. Vendor tiering can be used to negotiate better rates. Reduced administrative labor hours creates more efficient use of resources. Program transparency provides tremendous detail about spending, keeping you on budget when making financial decisions.</p>
<p class="p1"><b>Increase Quality<br>
</b>Real-time profile matching ensures that candidates are compliant and credentialed, guaranteeing reliable, consistent quality. Rating systems help reduce the chance of a poor fit by allowing you to choose candidates based on prior performance and visit history.</p>

		</div>
	</div>
</div></div></div></div>
</div>
@include('../SBSC/footer')