@include('../SBSC/header')
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(../wp-content/uploads/2021/07/sbsc-logo-patternc993.png?id=556) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629380533203{margin-bottom: 50px !important;}.vc_custom_1629381957221{margin-top: 0px !important;margin-bottom: 250px !important;padding-top: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="../wp-content/uploads/2021/09/sbscFav.png" />
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629380533203" >
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="../index.html">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Global Presence</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">SBSC</span> India</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629381957221"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<h4 style="text-align: center;">Innovation. Strategy. Timeliness. Creativity. Excellence. Integrity.</h4>
<p class="p1" style="text-align: center;">These are all key factors that drive our <span class="s1"><b>SBSC </b></span>team.</p>

		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p class="p1" style="margin-top: 0;">The SBSC India office is the hub of our development team, where we have tapped into top talent, who enable us to cater to the diverse needs of our clients, ranging from strategic consulting, to application development, to application support &amp; maintenance, to mobile application and website design or any other niche technology-driven initiative. Our offshore team allows us the capability to provide 24 x 7 coverage to our business partners, wherever needed. Our team is made up of extremely talented people who are able to consistently deliver on our promise of “delivering differently”.</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey">
                <img width="469" height="324" src="images/sbscNoida.png" class="vc_single_image-img attachment-full" alt="" decoding="async" loading="lazy" sizes="(max-width: 469px) 100vw, 469px" /></div>
		</figure>
	</div>
</div></div></div></div></div></div></div></div>
</div>
@include('../SBSC/footer')
