hi this is page
<a href="/">Home </a><?php /**PATH G:\SBSC\new_site\resources\views//contact.blade.php ENDPATH**/ ?>