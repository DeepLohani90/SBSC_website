<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_custom-css">.container-custom{width:1140px;}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1629449092811{margin-bottom: 100px !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629449916506{margin-bottom: 50px !important;}.vc_custom_1629441601791{margin-top: 0px !important;margin-bottom: 0px !important;padding-top: 0px !important;}.vc_custom_1629452757283{margin-bottom: 0px !important;}.vc_custom_1629452795964{margin-bottom: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
    <div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629449916506">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Careers</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Career</span> Africa</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629441601791"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="globalPresence wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p>At SBSC we provide holistic employment experience with flexibility to balance both your professional and personal life along with the joy of working on latest technologies. Discover the world of innovation, learning, growth and equal opportunities with us. Looking forward for reshaping your career with us.. Listed below are some current openings we are hiring for. Can’t find the vacancy you seek?.. No Worries .. Mail your CV to us at <a href="mailto:careers@sbsc.com">careers@sbsc.com</a> and we will get back to you.</p>

		</div>
	</div>

	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4 class="vc_custom_heading vc_custom_1492689453089">Current Job Openings</h4>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="container container-custom"><div class="vc_row wpb_row vc_row-fluid cusContainer vc_custom_1629449092811"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_tta-container" data-vc-action="collapseAll"><div class="vc_general vc_tta vc_tta-accordion vc_tta-color-blue vc_tta-style-classic vc_tta-shape-rounded vc_tta-o-shape-group vc_tta-controls-align-left vc_tta-o-all-clickable"><div class="vc_tta-panels-container"><div class="vc_tta-panels"><div class="vc_tta-panel" id="1629437358260-7757595d-33b6" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629437358260-7757595d-33b6" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-chart-pie"></i><span class="vc_tta-title-text">Business Analyst</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629452757283">
		<div class="wpb_wrapper">
			<p><strong>Job Description:</strong></p>
<p>The ideal candidate should have hands on experience in putting together RFPs / PPTs / Prototypes for development projects using java / .net / php / html etc.</p>
<ul class="ms-cus-ul">
<li>Assisting with the business case</li>
<li>Planning and monitoring</li>
<li>Eliciting requirements</li>
<li>Requirements organization</li>
<li>Translating and simplifying requirements</li>
<li>Requirements management and communication</li>
<li>Requirements analysis</li>
<li>Drive the design or review of test cases, process change requests, and manage a project’s scope, acceptance, installation and deployment.</li>
<li>Written and verbal communication, including technical writing skills</li>
<li>Understanding of systems engineering concepts</li>
<li>The ability to conduct cost / benefit analysis</li>
<li>Business case development</li>
<li>Modeling techniques and methods</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div><div class="vc_tta-panel" id="1629448682378-62c948dc-099e" data-vc-content=".vc_tta-panel-body"><div class="vc_tta-panel-heading"><h4 class="vc_tta-panel-title vc_tta-controls-icon-position-left"><a href="#1629448682378-62c948dc-099e" data-vc-accordion data-vc-container=".vc_tta-container"><i class="vc_tta-icon fas fa-terminal"></i><span class="vc_tta-title-text">SSIS / SSRS Developer</span><i class="vc_tta-controls-icon vc_tta-controls-icon-chevron"></i></a></h4></div><div class="vc_tta-panel-body">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629452795964">
		<div class="wpb_wrapper">
			<p><strong>Mandatory Skills</strong></p>
<ol>
<li>Excellent Knowledge in SQL Query (SQL Server 2008 / 2012)</li>
<li>Excellent Knowledge of SSRS, SSIS using SQL Server 2012 and above.</li>
<li>Knowledge of SSAS is preferred but not mandatory.</li>
<li>Knowledge of Microsoft Visual Studio .NET and Programming in ASP.NET</li>
<li>Excellent Knowledge of Functions and Stored procedures (SQL Server 2008/2012)</li>
<li>Knowledge of C# / VB.net / ASP.net will be a Plus.</li>
</ol>
<p><strong>Job Description:</strong></p>
<ul class="ms-cus-ul">
<li>Develop and implement BI projects, reports and packages using SSIS, SSAS, SSRS and Microsoft database tools.</li>
<li>The developer should create reports to be published on to a Report Server using Microsoft SSRS design tools that use Report Definition Language (RDL), an XML-based industry standard used to define reports.</li>
<li>Using Microsoft Visual Studio .NET and the Microsoft .NET Framework, developer should leverage the capabilities of their existing information systems</li>
<li>MS BI Suite including SQL Server, Integration Services and Reporting Services</li>
<li>Preference will be given to the candidates having knowledge of MS Access database.</li>
<li>Knowledge in crystal report is an added advantage.</li>
</ul>

		</div>
	</div>
<div class="vc_btn3-container vc_btn3-inline"><a class="vc_general vc_btn3 vc_btn3-size-sm vc_btn3-shape-round vc_btn3-style-modern vc_btn3-color-blue" href="mailto:careers@sbsc.com" title>Apply for this job</a></div></div></div></div></div></div></div></div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/africa.blade.php ENDPATH**/ ?>