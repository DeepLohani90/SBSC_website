<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title><?php echo e($title); ?></title>
<?php echo e($title); ?>


<a href="/contact">Contact</a><?php /**PATH G:\SBSC\new_site\resources\views/welcome.blade.php ENDPATH**/ ?>