<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629309264421{margin-bottom: 50px !important;}.vc_custom_1629381985608{margin-bottom: 250px !important;padding-top: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
	<link rel="shortcut icon" href="images/sbscFav.png">
	
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages spaceBottomLow wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629309264421">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">More About Us</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Corporate</span> Responsibility</h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner vc_custom_1629381985608"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<h4>SBSC Contributes to Many Charitable Events</h4>
<p>An important part of who we are as a company is our dedication to serving the communities in which we live and work. SBSC contributes to many causes and participates in charitable and community events that matter to our families and our clients around the country. Here are just a few of the organizations we have supported:</p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="678" height="179" src="images/socialResponsibility.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy" srcset="images/socialResponsibility.jpg 678w, images/socialResponsibility-300x79.jpg 300w" sizes="(max-width: 678px) 100vw, 678px"></div>
		</figure>
	</div>
</div></div></div></div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/corporate-social-responsibility.blade.php ENDPATH**/ ?>