<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1626972436372{background-image: url(images/sbsc-logo-pattern.png) !important;}.vc_custom_1626973481742{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629281090649{margin-bottom: 50px !important;}.vc_custom_1629291515224{margin-bottom: 50px !important;}.vc_custom_1629291720042{margin-right: 0px !important;}.vc_custom_1629299602578{margin-right: 0px !important;margin-left: 0px !important;}.vc_custom_1629291736032{margin-left: 0px !important;}.vc_custom_1629299129252{border-right-width: 1px !important;border-right-color: #ffffff !important;border-right-style: solid !important;}.vc_custom_1629299080446{border-left-width: 1px !important;border-left-color: #ffffff !important;border-left-style: solid !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style type="text/css">/** Mega Menu CSS: fs **/</style>
<style type="text/css">
	@media (min-width:110px) and (max-width:767px)
	{
		.mobile-bg-custom
		{
			border-color: #e7e7e7 !important;
			border-left-style: none !important;
		}
		.setupmargin
		{
			margin-bottom: -70px;
		}
	}
</style>

	<link rel="shortcut icon" href="images/sbscFav.png">
	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12 setupmargin"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629291515224">
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="http://www.sbsc.com">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">More About Us</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Mission, Vision &amp; Values</span></h1>

		</div>
	</div>
</div></div></div></div></div></div></div></div><div class="container container-custom"><div class="vc_row wpb_row vc_row-fluid"><div class="missionVissionValue wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap m-none"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner vc_custom_1629291720042"><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="topOurMissionLeft"></div>
		</div>
	</div>
</div></div></div><div class="mvvLogoBox wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner vc_custom_1629299602578"><div class="wpb_wrapper">
	<div class="wpb_single_image wpb_content_element vc_align_center">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="139" height="138" src="images/SBSCLogoMVV.jpg" class="vc_single_image-img attachment-full" alt decoding="async" loading="lazy"></div>
		</figure>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner vc_custom_1629291736032"><div class="wpb_wrapper">
	<div class="wpb_raw_code wpb_content_element wpb_raw_html">
		<div class="wpb_wrapper">
			<div class="topOurMissionRight"></div>
		</div>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_inner container bootstrap mvv2"><div class="mvvBox wpb_column vc_column_container vc_col-sm-4 vc_col-has-fill"><div class="vc_column-inner vc_custom_1629299129252"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p><img decoding="async" class="size-full wp-image-1102 aligncenter" src="images/ourMissionIcon.png" alt width="105" height="105"></p>
<h4 class="p1" style="text-align: center;">Our Mission</h4>
<p class="p1" style="text-align: center;">To consistently deliver value to our clients by providing creative and forward thinking solutions, by collaborating and creating long-term relationships through our dedicated team of professionals, committed to exceptional service.</p>

		</div>
	</div>
</div></div></div><div class="mvvBox wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element ">
		<div class="wpb_wrapper">
			<p><img decoding="async" loading="lazy" class="wp-image-1104 size-full aligncenter" src="images/ourVissionIcon.png" alt width="105" height="105"></p>
<h4 class="p1" style="text-align: center;">Our Vision</h4>
<p class="p1" style="text-align: center;">To be a trusted and respected business and technology consulting firm, recognized for delivering exceptional value and actionable result to clients.</p>

		</div>
	</div>
</div></div></div><div class="mvvBox wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner"><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element vc_custom_1629299080446  mobile-bg-custom">
		<div class="wpb_wrapper">
			<p><img decoding="async" loading="lazy" class="wp-image-1103 size-full aligncenter" src="images/ourValuesIcon.png" alt width="105" height="105"></p>
<h4 class="p1" style="text-align: center;">Our Values</h4>
<p class="p1" style="text-align: center;">Customer Centric, Respect for the individual needs of our clients Quality, Embracing change with speed and excellence, Integrity.</p>

		</div>
	</div>
</div></div></div></div></div></div></div></div></div>
</div>
<?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/new_site/resources/views/SBSC/mission-vision-values.blade.php ENDPATH**/ ?>