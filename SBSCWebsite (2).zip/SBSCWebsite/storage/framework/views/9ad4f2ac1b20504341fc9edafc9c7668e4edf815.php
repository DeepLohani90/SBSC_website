<?php echo $__env->make('../SBSC/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- End of header -->

	<div class="vc_row wpb_row vc_row-fluid vc_custom_1626972436372 vc_row-has-fill nt-theme-extra-row-bgposition-vc_custom_1626972436372"><style>.vc_row.nt-theme-extra-row-bgposition-vc_custom_1626972436372{background-position:left top !important;}</style><div class="spaceInnerPages wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner container bootstrap vc_custom_1626973481742"><style> @media  only screen and (max-width: 992px) { .{margin-bottom: 50px !important;} }</style><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1629285932157" >
		<div class="wpb_wrapper">
			<div class="breadCrumbCustom">
<div class="d-inline"><a href="../index.html">Home</a></div>
<div class="d-inline">/</div>
<div class="d-inline breadPresent">Company Overview</div>
</div>
<h1 class="h1Original" style="text-align: left;"><span class="orange">Our Partnerships</span></h1>

		</div>
	</div>
</div></div></div></div>
<!-- partner space start -->

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<div class="container">
	<div class="gs_logo_container gs_logo_container_list">

	
		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="114" height="15" src="images/collabNetLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" title="Colabnet">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">Colabnet</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>As part of our partnership with Collabnet, we undertake service assignments for the implementation of the Teamforge Tool. We also partner as a seller of licenses.</p>
</div>					</div>

				</div>
			</div>

		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="116" height="54" src="images/msCertifiedLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" loading="lazy" title="Microsoft">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">Microsoft</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>As a Microsoft Certified Partner, we help customers with a range of IT projects and specific IT solutions.</p>
</div>					</div>

				</div>
			</div>

		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="122" height="47" src="images/ibmLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" loading="lazy" title="IBM">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">IBM</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>SBSC has partnered with IBM for Sales, Implementation and Maintenance of IBM’s Information Management and Big Data products. We are authorized to sell and Implement a wide range of IBM products that include SPSS Business Analytics products, Cognos Business Intelligence solution, DB2 and Informix database, Infosphere Data Warehouse suite and IBM BigInsights (Hadoop) suite of products.</p>
</div>					</div>

				</div>
			</div>

		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="120" height="36" src="images/talenGuardLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" loading="lazy" title="Talent Guard">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">Talent Guard</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>The talent management software suite integrates the vital HR areas including performance management, career pathing, succession planning, 360 feedback, applicant tracking, learning management, development planning and coaching – all of which contribute to the creation of a high-performance culture.</p>
</div>					</div>

				</div>
			</div>

		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="122" height="32" src="images/oracleLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" loading="lazy" title="Oracle">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">Oracle</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>As a member of the Oracle Partner Network, we have the access and ability to develop and sell across Oracle’s entire product portfolio.</p>
</div>					</div>

				</div>
			</div>

		
			<div class="gs_logo_single--wrapper">
				<div class="gs_logo_single">
					
					<div class="gs_logo--image-area">
						<!-- Logo Image -->
						<img width="118" height="52" src="images/bmcLogo.png" class="gs-logo--img wp-post-image" alt="" decoding="async" loading="lazy" title="BMC">					</div>

					<div class="gs_logo--details-area">
						<!-- Logo Title -->
						    <h3 class="gs_logo_title">BMC</h3>
						<!-- Logo Details -->
						
<div class="gs-logo-details justify"><p>BMC develops products and services that address six principles of digital transformation: intuitive user experience, adaptive automation, actionable intelligence, optimized infrastructure cost, agile applications and compliance risk. We partner with BMC to leverage this leading-edge platform to provide a competitive business advantage to customers by helping them to cut costs, reduce risk and achieve business objectives.</p>
</div>					</div>

				</div>
			</div>

				
	
</div>
	</div>
</div>

<!-- partner space end -->

</div></div></div></div>
</div>
<!-- End of main-content -->
 <?php echo $__env->make('../SBSC/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of footer -->
    <script type="text/html" id="wpb-modifications"></script><link rel='stylesheet' id='gs-tippyjs-css' href='../wp-content/plugins/gs-logo-slider/assets/libs/tippyjs/tippy677a.css?ver=3.0.9' type='text/css' media='all' />
<link rel='stylesheet' id='gs-logo-public-css' href='../wp-content/plugins/gs-logo-slider/assets/css/gs-logo.min677a.css?ver=3.0.9' type='text/css' media='all' />
<style id='gs-logo-public-inline-css' type='text/css'>
	
		
		.gs_logo_area_1:not(.verticaltickerdown):not(.verticalticker) .gs_logo_container {
		margin-left: -5px;
		margin-right: -5px;
	}
	
		.gs_logo_area_1:not(.verticaltickerdown):not(.verticalticker) .gs_logo_single--wrapper {
		padding: 5px;
	}
	
		.gs_logo_area_1 ul.gs-logo-filter-cats {
		text-align: center !important;
	}
	
	.gs_logo_area_1 .gs_logo_single--wrapper {
		width: 20%;
	}
	
	@media (max-width: 1023px) {
		.gs_logo_area_1 .gs_logo_single--wrapper {
			width: 33.333333333333%;
		}
	}
	
	@media (max-width: 767px) {
		.gs_logo_area_1 .gs_logo_single--wrapper {
			width: 50%;
		}
	}

	
</style>
<script type='text/javascript' src='../wp-includes/js/dist/vendor/regenerator-runtime.min3937.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script type='text/javascript' src='../wp-includes/js/dist/vendor/wp-polyfill.min2c7c.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/www.sbsc.com\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/plugins/contact-form-7/includes/js/index7661.js?ver=5.4.2' id='contact-form-7-js'></script>
<script type='text/javascript' src='../wp-includes/js/comment-reply.min6a4d.js?ver=6.1.1' id='comment-reply-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/jquery.nav5152.js?ver=1.0' id='jquery-nav-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/bootstrap.min5152.js?ver=1.0' id='bootstrap-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/jquery.waypoints.min5152.js?ver=1.0' id='waypoints-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/wow.min5152.js?ver=1.0' id='wow-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/imagesLoaded.min5152.js?ver=1.0' id='imagesLoaded-js'></script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/main5152.js?ver=1.0' id='nt-antique-main-js'></script>
<script type='text/javascript' id='nt-antique-onepagenav-set-js-extra'>
/* <![CDATA[ */
var onepagenavprefix = {"topoffset":"80"};
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/themes/nt-antique/js/short/onepagenav-set5152.js?ver=1.0' id='nt-antique-onepagenav-set-js'></script>
<script type='text/javascript' src='../wp-includes/js/hoverIntent.min3e5a.js?ver=1.10.2' id='hoverIntent-js'></script>
<script type='text/javascript' id='megamenu-js-extra'>
/* <![CDATA[ */
var megamenu = {"timeout":"300","interval":"100"};
/* ]]> */
</script>
<script type='text/javascript' src='../wp-content/plugins/megamenu/js/maxmegamenuf0c3.js?ver=2.9.4' id='megamenu-js'></script>
<script type='text/javascript' src='../wp-content/plugins/js_composer/assets/js/dist/js_composer_front.minbdeb.js?ver=6.7.0' id='wpb_composer_front_js-js'></script>
<script type='text/javascript' src='../wp-content/plugins/gs-logo-slider/assets/libs/images-loaded/images-loaded.min677a.js?ver=3.0.9' id='gs-images-loaded-js'></script>
<script type='text/javascript' src='../wp-content/plugins/gs-logo-slider/assets/libs/tippyjs/tippy-bundle.umd.min677a.js?ver=3.0.9' id='gs-tippyjs-js'></script>
<script type='text/javascript' src='../wp-content/plugins/gs-logo-slider/assets/js/gs-logo.min677a.js?ver=3.0.9' id='gs-logo-public-js'></script>
</body>

<!-- Mirrored from www.sbsc.com/our-partnerships/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 17 Feb 2023 11:43:56 GMT -->
</html>
<?php /**PATH /Volumes/WorkSpace/SBSCLarawel/SBSCWebsite/resources/views/SBSC/our-partnerships.blade.php ENDPATH**/ ?>