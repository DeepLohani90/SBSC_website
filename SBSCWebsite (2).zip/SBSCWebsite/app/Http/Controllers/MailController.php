<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\Mail\DemoMail;

class MailController extends Controller
{
     public function index(Request $req)
    
    {
        $customer_mail = $req->email;
        $mailData = [
            'title' => $req->name,
            'body' => $req->message,
            'phone' => $req->phone
        ];
         
        Mail::to($customer_mail)->send(new DemoMail($mailData));
           
        return view('SBSC/index');
    }
}
